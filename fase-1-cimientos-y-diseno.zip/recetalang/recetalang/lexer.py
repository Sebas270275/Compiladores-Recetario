"""Analizador léxico escrito a mano (se implementará en la Fase 2)."""
