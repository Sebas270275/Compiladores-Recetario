"""Tipos y representación de tokens (se implementarán en la Fase 2)."""
