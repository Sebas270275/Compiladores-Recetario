"""Errores del compilador con fase y posición (se implementarán en la Fase 2)."""
