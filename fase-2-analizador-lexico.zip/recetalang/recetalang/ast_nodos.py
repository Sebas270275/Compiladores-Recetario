"""Nodos de datos del árbol sintáctico (se implementarán en la Fase 3)."""
