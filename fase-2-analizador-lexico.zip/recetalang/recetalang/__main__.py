"""Punto de entrada de la interfaz de línea de comandos (Fase 2)."""
