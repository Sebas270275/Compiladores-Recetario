"""Paquete del compilador de RecetaLang."""
