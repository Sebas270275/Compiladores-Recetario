"""Categorías y valores de los elementos reconocidos por el lexer."""

from dataclasses import dataclass
from enum import Enum, auto


class TipoToken(Enum):
    """Tipos separados para que el parser no dependa del texto del token."""

    AGREGAR = auto()
    MEZCLAR = auto()
    COCINAR = auto()
    REPETIR = auto()
    VECES = auto()
    SI = auto()
    ENTONCES = auto()
    SINO = auto()
    FIN = auto()
    IDENTIFICADOR = auto()
    ENTERO = auto()
    CADENA = auto()
    IGUAL = auto()
    MAS = auto()
    MENOS = auto()
    POR = auto()
    MAYOR = auto()
    MENOR = auto()
    IGUAL_IGUAL = auto()
    COMA = auto()
    PAREN_IZQ = auto()
    PAREN_DER = auto()
    NEWLINE = auto()
    EOF = auto()


PALABRAS_RESERVADAS = {
    "agregar": TipoToken.AGREGAR,
    "mezclar": TipoToken.MEZCLAR,
    "cocinar": TipoToken.COCINAR,
    "repetir": TipoToken.REPETIR,
    "veces": TipoToken.VECES,
    "si": TipoToken.SI,
    "entonces": TipoToken.ENTONCES,
    "sino": TipoToken.SINO,
    "fin": TipoToken.FIN,
}


@dataclass(frozen=True)
class Token:
    """Token con su texto original y posición inicial de base uno."""

    tipo: TipoToken
    lexema: str
    valor: int | str | None
    linea: int
    columna: int
