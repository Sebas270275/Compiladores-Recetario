"""Analiza variables, valores conocidos y los caminos de control del AST."""

from recetalang.ast_nodos import (
    Agregar,
    Asignacion,
    Cocinar,
    Condicional,
    Mezclar,
    Numero,
    OperacionBinaria,
    OperacionUnaria,
    Programa,
    Repetir,
    Sentencia,
    Variable,
)
from recetalang.errores import ErrorCompilador
from recetalang.tabla_simbolos import TablaSimbolos


class AnalizadorSemantico:
    """Recorre el AST en orden y recopila todos los errores semánticos."""

    def __init__(self) -> None:
        self.tabla = TablaSimbolos()
        self.errores: list[ErrorCompilador] = []
        self.hay_ingrediente = False

    def analizar(self, programa: Programa) -> tuple[TablaSimbolos, list[ErrorCompilador]]:
        self._visitar_bloque(programa.sentencias)
        self.errores.sort(key=lambda error: (error.linea, error.columna))
        return self.tabla, self.errores

    def _error_variable(self, variable: Variable) -> None:
        self.errores.append(
            ErrorCompilador(
                variable.linea,
                variable.columna,
                f"la variable «{variable.nombre}» no está definida",
                "Semántica",
            )
        )

    def _evaluar(self, expresion) -> int | None:
        if isinstance(expresion, Numero):
            return expresion.valor
        if isinstance(expresion, Variable):
            if not self.tabla.existe(expresion.nombre):
                self._error_variable(expresion)
                return None
            return self.tabla.valor(expresion.nombre)
        if isinstance(expresion, OperacionUnaria):
            valor = self._evaluar(expresion.operando)
            return -valor if valor is not None else None
        if isinstance(expresion, OperacionBinaria):
            izquierda = self._evaluar(expresion.izquierda)
            derecha = self._evaluar(expresion.derecha)
            if izquierda is None or derecha is None:
                return None
            if expresion.operador == "+":
                return izquierda + derecha
            if expresion.operador == "-":
                return izquierda - derecha
            return izquierda * derecha
        return None

    def _visitar_bloque(self, sentencias: list[Sentencia]) -> None:
        for sentencia in sentencias:
            self._visitar_sentencia(sentencia)

    def _visitar_sentencia(self, sentencia: Sentencia) -> None:
        if isinstance(sentencia, Asignacion):
            valor = self._evaluar(sentencia.expresion)
            self.tabla.definir(sentencia.nombre, valor)
        elif isinstance(sentencia, Agregar):
            self._visitar_agregar(sentencia)
        elif isinstance(sentencia, (Mezclar, Cocinar)):
            self._visitar_accion(sentencia)
        elif isinstance(sentencia, Repetir):
            self._visitar_repetir(sentencia)
        elif isinstance(sentencia, Condicional):
            self._visitar_condicional(sentencia)

    def _visitar_condicional(self, nodo: Condicional) -> None:
        self._evaluar(nodo.condicion.izquierda)
        self._evaluar(nodo.condicion.derecha)
        tabla_inicial = self.tabla.copiar()
        ingrediente_inicial = self.hay_ingrediente

        self.tabla = tabla_inicial.copiar()
        self.hay_ingrediente = ingrediente_inicial
        self._visitar_bloque(nodo.rama_si)
        tabla_si = self.tabla
        ingrediente_si = self.hay_ingrediente

        self.tabla = tabla_inicial.copiar()
        self.hay_ingrediente = ingrediente_inicial
        self._visitar_bloque(nodo.rama_sino)
        tabla_sino = self.tabla
        ingrediente_sino = self.hay_ingrediente

        self.tabla = TablaSimbolos.fusionar_ramas(tabla_si, tabla_sino)
        self.hay_ingrediente = ingrediente_si and ingrediente_sino

    def _posicion_inicio(self, expresion) -> tuple[int, int]:
        """Busca el primer carácter de la expresión para ubicar R1, R2 y R3."""
        if isinstance(expresion, OperacionBinaria):
            return self._posicion_inicio(expresion.izquierda)
        return expresion.linea, expresion.columna

    def _error_regla(self, linea: int, columna: int, mensaje: str) -> None:
        self.errores.append(
            ErrorCompilador(linea, columna, mensaje, "Semántica")
        )

    def _visitar_agregar(self, nodo: Agregar) -> None:
        cantidad = self._evaluar(nodo.cantidad)
        if cantidad is not None and cantidad <= 0:
            linea, columna = self._posicion_inicio(nodo.cantidad)
            self._error_regla(
                linea,
                columna,
                f"[R1] la cantidad debe ser mayor que cero (valor: {cantidad})",
            )
        if nodo.unidad not in {"g", "ml"}:
            self._error_regla(
                nodo.unidad_linea,
                nodo.unidad_columna,
                f"[U1] unidad «{nodo.unidad}» no admitida (use «g» o «ml»)",
            )
        self.hay_ingrediente = True

    def _visitar_accion(self, nodo: Mezclar | Cocinar) -> None:
        tiempo = self._evaluar(nodo.tiempo)
        if not self.hay_ingrediente:
            self._error_regla(
                nodo.linea,
                nodo.columna,
                "[R4] se debe agregar al menos un ingrediente antes de mezclar o cocinar",
            )
        if tiempo is not None and tiempo <= 0:
            linea, columna = self._posicion_inicio(nodo.tiempo)
            self._error_regla(
                linea,
                columna,
                f"[R2] el tiempo debe ser mayor que cero (valor: {tiempo})",
            )

    def _visitar_repetir(self, nodo: Repetir) -> None:
        cantidad = self._evaluar(nodo.veces)
        if cantidad is not None and cantidad <= 0:
            linea, columna = self._posicion_inicio(nodo.veces)
            self._error_regla(
                linea,
                columna,
                f"[R3] la repetición debe ser mayor que cero (valor: {cantidad})",
            )
        for nombre in self._asignaciones_en(nodo.cuerpo):
            self.tabla.definir(nombre, None)
        self._visitar_bloque(nodo.cuerpo)

    def _asignaciones_en(self, sentencias: list[Sentencia]) -> set[str]:
        """Busca asignaciones anidadas para invalidar sus valores al entrar al bucle."""
        nombres = set()
        for sentencia in sentencias:
            if isinstance(sentencia, Asignacion):
                nombres.add(sentencia.nombre)
            elif isinstance(sentencia, Repetir):
                nombres.update(self._asignaciones_en(sentencia.cuerpo))
            elif isinstance(sentencia, Condicional):
                nombres.update(self._asignaciones_en(sentencia.rama_si))
                nombres.update(self._asignaciones_en(sentencia.rama_sino))
        return nombres


def analizar(programa: Programa) -> tuple[TablaSimbolos, list[ErrorCompilador]]:
    """Interfaz pública del análisis de variables y valores constantes."""
    return AnalizadorSemantico().analizar(programa)
