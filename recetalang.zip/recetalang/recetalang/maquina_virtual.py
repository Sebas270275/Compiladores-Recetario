"""Máquina de pila pequeña que ejecuta el bytecode de RecetaLang."""


class ErrorMaquinaVirtual(RuntimeError):
    """Fallo de ejecución con una explicación útil para quien depura."""


def ejecutar(
    bytecode: list[tuple[str, object]], max_pasos: int = 100_000
) -> list[str]:
    """Ejecuta instrucciones, conserva variables y devuelve el registro culinario."""
    pila: list[object] = []
    variables: dict[str, object] = {}
    registro: list[str] = []
    contador = 0
    pasos = 0

    def sacar() -> object:
        if not pila:
            raise ErrorMaquinaVirtual("la pila quedó vacía cuando se necesitaba un valor")
        return pila.pop()

    while 0 <= contador < len(bytecode):
        pasos += 1
        if pasos > max_pasos:
            raise ErrorMaquinaVirtual(
                f"se superó el límite de {max_pasos} pasos; posible bucle infinito"
            )
        operacion, argumento = bytecode[contador]
        if operacion == "PUSH":
            pila.append(argumento)
        elif operacion == "LOAD":
            if argumento not in variables:
                raise ErrorMaquinaVirtual(f"la variable interna «{argumento}» no existe")
            pila.append(variables[argumento])
        elif operacion == "STORE":
            variables[str(argumento)] = sacar()
        elif operacion in {"ADD", "SUB", "MUL", "GT", "LT", "EQ"}:
            derecha = sacar()
            izquierda = sacar()
            if operacion == "ADD":
                pila.append(izquierda + derecha)
            elif operacion == "SUB":
                pila.append(izquierda - derecha)
            elif operacion == "MUL":
                pila.append(izquierda * derecha)
            elif operacion == "GT":
                pila.append(int(izquierda > derecha))
            elif operacion == "LT":
                pila.append(int(izquierda < derecha))
            else:
                pila.append(int(izquierda == derecha))
        elif operacion == "NEG":
            pila.append(-sacar())
        elif operacion == "JMP":
            contador = int(argumento)
            continue
        elif operacion == "JZ":
            if sacar() == 0:
                contador = int(argumento)
                continue
        elif operacion == "AGREGAR":
            unidad = sacar()
            cantidad = sacar()
            ingrediente = sacar()
            registro.append(
                f"AGREGAR(ingrediente={ingrediente}, cantidad={cantidad}, unidad={unidad})"
            )
        elif operacion in {"MEZCLAR", "COCINAR"}:
            minutos = sacar()
            nombre = "MEZCLAR" if operacion == "MEZCLAR" else "COCINAR"
            registro.append(f"{nombre}(minutos={minutos})")
        else:
            raise ErrorMaquinaVirtual(f"operación de bytecode desconocida: {operacion}")
        contador += 1
    if contador < 0 or contador > len(bytecode):
        raise ErrorMaquinaVirtual("el contador de programa salió de los límites del bytecode")
    return registro
