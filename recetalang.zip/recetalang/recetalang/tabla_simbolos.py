"""Almacena variables y combina los estados que sobreviven a un condicional."""


class TablaSimbolos:
    """Asocia cada nombre con un entero conocido o con valor desconocido."""

    def __init__(self, valores: dict[str, int | None] | None = None) -> None:
        self._valores = dict(valores or {})

    def definir(self, nombre: str, valor: int | None) -> None:
        self._valores[nombre] = valor

    def existe(self, nombre: str) -> bool:
        return nombre in self._valores

    def valor(self, nombre: str) -> int | None:
        return self._valores.get(nombre)

    def copiar(self) -> "TablaSimbolos":
        return TablaSimbolos(self._valores)

    @staticmethod
    def fusionar_ramas(a: "TablaSimbolos", b: "TablaSimbolos") -> "TablaSimbolos":
        """Conserva solo nombres presentes en ambas ramas y valores coincidentes."""
        comunes = a._valores.keys() & b._valores.keys()
        resultado = {}
        for nombre in comunes:
            valor_a = a._valores[nombre]
            valor_b = b._valores[nombre]
            resultado[nombre] = valor_a if valor_a == valor_b else None
        return TablaSimbolos(resultado)

    def como_dict(self) -> dict[str, int | None]:
        return dict(self._valores)
