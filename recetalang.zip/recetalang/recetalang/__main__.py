"""Punto de entrada de la interfaz de línea de comandos."""

import argparse
from pathlib import Path
from pprint import pformat
import sys

from recetalang.lexer import tokenizar
from recetalang.compilador import compilar


def main() -> int:
    """Permite inspeccionar tokens y AST desde un archivo de receta."""
    parser = argparse.ArgumentParser(prog="python -m recetalang")
    parser.add_argument("archivo", type=Path)
    parser.add_argument("--tokens", action="store_true", help="mostrar tokens")
    parser.add_argument("--ast", action="store_true", help="mostrar el AST")
    parser.add_argument("--simbolos", action="store_true", help="mostrar variables")
    parser.add_argument("--bytecode", action="store_true", help="mostrar bytecode")
    parser.add_argument("--solo-compilar", action="store_true", help="no ejecutar el bytecode")
    argumentos = parser.parse_args()
    try:
        texto = argumentos.archivo.read_text(encoding="utf-8")
    except OSError as error:
        print(f"No se pudo leer el archivo: {error}", file=sys.stderr)
        return 1

    tokens, errores = tokenizar(texto)
    if argumentos.tokens:
        print(f"{'LÍNEA':>5} {'COL':>4} {'TIPO':<16} LEXEMA")
        for token in tokens:
            lexema = token.lexema.replace("\n", "\\n")
            print(f"{token.linea:5} {token.columna:4} {token.tipo.name:<16} {lexema}")
    for error in errores:
        print(f"[{error.fase}] {error.formato()}", file=sys.stderr)
    if argumentos.tokens:
        return 1 if errores else 0
    if errores:
        return 1
    if argumentos.bytecode or argumentos.solo_compilar:
        limite = "codigo"
    elif argumentos.simbolos:
        limite = "semantico"
    elif argumentos.ast:
        limite = "sintactico"
    else:
        limite = "ejecucion"
    resultado = compilar(texto, hasta_fase=limite)
    if resultado.errores:
        for error in resultado.errores:
            print(f"[{error.fase}] {error.formato()}", file=sys.stderr)
        return 1
    if argumentos.ast and resultado.ast is not None:
        print(pformat(resultado.ast, width=88, sort_dicts=False))
    if argumentos.simbolos:
        for nombre, valor in sorted(resultado.simbolos.items()):
            texto_valor = str(valor) if valor is not None else "desconocido"
            print(f"{nombre} → {texto_valor}")
    if argumentos.bytecode:
        for indice, (operacion, argumento) in enumerate(resultado.bytecode):
            if argumento is None:
                print(f"{indice:04}: {operacion}")
            else:
                print(f"{indice:04}: {operacion} {argumento}")
        return 0
    if argumentos.solo_compilar:
        print("Compilación correcta; no se ejecutó el bytecode.")
        return 0
    if argumentos.ast or argumentos.simbolos:
        return 0
    for linea in resultado.salida:
        print(linea)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
