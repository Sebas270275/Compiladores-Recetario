"""Errores del compilador con una posición uniforme para todas las fases."""


class ErrorCompilador(Exception):
    """Representa un error que puede mostrarse sin perder su fase de origen."""

    def __init__(self, linea: int, columna: int, mensaje: str, fase: str) -> None:
        super().__init__(mensaje)
        self.linea = linea
        self.columna = columna
        self.mensaje = mensaje
        self.fase = fase

    def __str__(self) -> str:
        return self.formato()

    def formato(self) -> str:
        """Devuelve el formato estable usado por las pruebas y la CLI."""
        return f"Línea {self.linea}, columna {self.columna}: {self.mensaje}"
