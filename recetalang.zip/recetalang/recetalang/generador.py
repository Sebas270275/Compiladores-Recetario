"""Traduce el AST a instrucciones de pila con saltos resueltos a índices."""

from recetalang.ast_nodos import (
    Agregar,
    Asignacion,
    Cocinar,
    Condicional,
    Mezclar,
    Numero,
    OperacionBinaria,
    OperacionUnaria,
    Programa,
    Repetir,
    Sentencia,
    Variable,
)


class Generador:
    """Emite instrucciones en orden y resuelve etiquetas al finalizar."""

    def __init__(self) -> None:
        self.codigo: list[tuple[str, object]] = []
        self.etiquetas: dict[str, int] = {}
        self.saltos: list[tuple[int, str]] = []
        self.numero_etiqueta = 0
        self.numero_repetir = 0

    def generar(self, programa: Programa) -> list[tuple[str, object]]:
        self._bloque(programa.sentencias)
        for posicion, nombre in self.saltos:
            operacion, _ = self.codigo[posicion]
            self.codigo[posicion] = (operacion, self.etiquetas[nombre])
        return self.codigo

    def _nueva_etiqueta(self, prefijo: str) -> str:
        nombre = f"{prefijo}{self.numero_etiqueta}"
        self.numero_etiqueta += 1
        return nombre

    def _marcar(self, nombre: str) -> None:
        self.etiquetas[nombre] = len(self.codigo)

    def _saltar(self, operacion: str, etiqueta: str) -> None:
        posicion = len(self.codigo)
        self.codigo.append((operacion, etiqueta))
        self.saltos.append((posicion, etiqueta))

    def _bloque(self, sentencias: list[Sentencia]) -> None:
        for sentencia in sentencias:
            self._sentencia(sentencia)

    def _sentencia(self, sentencia: Sentencia) -> None:
        if isinstance(sentencia, Asignacion):
            self._expresion(sentencia.expresion)
            self.codigo.append(("STORE", sentencia.nombre))
        elif isinstance(sentencia, Agregar):
            self.codigo.append(("PUSH", sentencia.ingrediente))
            self._expresion(sentencia.cantidad)
            self.codigo.append(("PUSH", sentencia.unidad))
            self.codigo.append(("AGREGAR", None))
        elif isinstance(sentencia, Mezclar):
            self._expresion(sentencia.tiempo)
            self.codigo.append(("MEZCLAR", None))
        elif isinstance(sentencia, Cocinar):
            self._expresion(sentencia.tiempo)
            self.codigo.append(("COCINAR", None))
        elif isinstance(sentencia, Condicional):
            self._condicional(sentencia)
        elif isinstance(sentencia, Repetir):
            self._repetir(sentencia)

    def _expresion(self, expresion) -> None:
        if isinstance(expresion, Numero):
            self.codigo.append(("PUSH", expresion.valor))
        elif isinstance(expresion, Variable):
            self.codigo.append(("LOAD", expresion.nombre))
        elif isinstance(expresion, OperacionUnaria):
            self._expresion(expresion.operando)
            self.codigo.append(("NEG", None))
        elif isinstance(expresion, OperacionBinaria):
            self._expresion(expresion.izquierda)
            self._expresion(expresion.derecha)
            operacion = {"+": "ADD", "-": "SUB", "*": "MUL"}[expresion.operador]
            self.codigo.append((operacion, None))

    def _condicional(self, nodo: Condicional) -> None:
        self._expresion(nodo.condicion.izquierda)
        self._expresion(nodo.condicion.derecha)
        operacion = {">": "GT", "<": "LT", "==": "EQ"}[nodo.condicion.operador]
        self.codigo.append((operacion, None))
        etiqueta_sino = self._nueva_etiqueta("L")
        etiqueta_fin = self._nueva_etiqueta("L")
        self._saltar("JZ", etiqueta_sino)
        self._bloque(nodo.rama_si)
        self._saltar("JMP", etiqueta_fin)
        self._marcar(etiqueta_sino)
        self._bloque(nodo.rama_sino)
        self._marcar(etiqueta_fin)

    def _repetir(self, nodo: Repetir) -> None:
        contador = f"$rep{self.numero_repetir}"
        self.numero_repetir += 1
        etiqueta_inicio = self._nueva_etiqueta("L")
        etiqueta_fin = self._nueva_etiqueta("L")
        self._expresion(nodo.veces)
        self.codigo.append(("STORE", contador))
        self._marcar(etiqueta_inicio)
        self.codigo.extend([("LOAD", contador), ("PUSH", 0), ("GT", None)])
        self._saltar("JZ", etiqueta_fin)
        self._bloque(nodo.cuerpo)
        self.codigo.extend([("LOAD", contador), ("PUSH", 1), ("SUB", None), ("STORE", contador)])
        self._saltar("JMP", etiqueta_inicio)
        self._marcar(etiqueta_fin)


def generar(programa: Programa) -> list[tuple[str, object]]:
    """Función pública: AST validado a lista determinista de instrucciones."""
    return Generador().generar(programa)
