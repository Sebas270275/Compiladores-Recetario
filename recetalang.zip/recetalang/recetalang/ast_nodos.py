"""Nodos de datos del AST con la posición de inicio de cada construcción."""

from dataclasses import dataclass, field


@dataclass
class Numero:
    linea: int
    columna: int
    valor: int


@dataclass
class Variable:
    linea: int
    columna: int
    nombre: str


@dataclass
class OperacionBinaria:
    linea: int
    columna: int
    operador: str
    izquierda: "Expresion"
    derecha: "Expresion"


@dataclass
class OperacionUnaria:
    linea: int
    columna: int
    operador: str
    operando: "Expresion"


Expresion = Numero | Variable | OperacionBinaria | OperacionUnaria


@dataclass
class Comparacion:
    linea: int
    columna: int
    izquierda: Expresion
    operador: str
    derecha: Expresion


@dataclass
class Asignacion:
    linea: int
    columna: int
    nombre: str
    expresion: Expresion


@dataclass
class Agregar:
    linea: int
    columna: int
    ingrediente: str
    cantidad: Expresion
    unidad: str
    unidad_linea: int
    unidad_columna: int


@dataclass
class Mezclar:
    linea: int
    columna: int
    tiempo: Expresion


@dataclass
class Cocinar:
    linea: int
    columna: int
    tiempo: Expresion


@dataclass
class Repetir:
    linea: int
    columna: int
    veces: Expresion
    cuerpo: list["Sentencia"] = field(default_factory=list)


@dataclass
class Condicional:
    linea: int
    columna: int
    condicion: Comparacion
    rama_si: list["Sentencia"] = field(default_factory=list)
    rama_sino: list["Sentencia"] = field(default_factory=list)


Sentencia = Asignacion | Agregar | Mezclar | Cocinar | Repetir | Condicional


@dataclass
class Programa:
    linea: int
    columna: int
    sentencias: list[Sentencia] = field(default_factory=list)
