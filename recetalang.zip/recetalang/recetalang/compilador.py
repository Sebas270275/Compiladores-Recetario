"""Orquesta lexer y parser y detiene el flujo ante el primer fallo de fase."""

from dataclasses import dataclass, field

from recetalang.ast_nodos import Programa
from recetalang.errores import ErrorCompilador
from recetalang.lexer import tokenizar
from recetalang.parser import parsear
from recetalang.tokens import Token


@dataclass
class ResultadoCompilacion:
    """Datos disponibles al finalizar una fase del compilador."""

    fase: str
    tokens: list[Token] = field(default_factory=list)
    ast: Programa | None = None
    errores: list[ErrorCompilador] = field(default_factory=list)
    simbolos: dict[str, int | None] = field(default_factory=dict)
    bytecode: list[tuple[str, object]] = field(default_factory=list)
    salida: list[str] = field(default_factory=list)

    @property
    def correcto(self) -> bool:
        return not self.errores


_FASES = {
    "lexico": 1,
    "léxico": 1,
    "tokens": 1,
    "1": 1,
    "sintactico": 2,
    "sintáctico": 2,
    "parser": 2,
    "2": 2,
    "semantico": 3,
    "semántico": 3,
    "3": 3,
    "codigo": 4,
    "código": 4,
    "generacion": 4,
    "generación": 4,
    "4": 4,
    "ejecucion": 5,
    "ejecución": 5,
    "5": 5,
}


def _normalizar_fase(hasta_fase: str | int) -> int:
    if isinstance(hasta_fase, int):
        if 1 <= hasta_fase <= 5:
            return hasta_fase
        raise ValueError("hasta_fase debe estar entre 1 y 5")
    nombre = hasta_fase.lower().strip()
    if nombre not in _FASES:
        raise ValueError(f"fase no reconocida: {hasta_fase}")
    return _FASES[nombre]


def compilar(texto: str, hasta_fase: str | int = "sintactico") -> ResultadoCompilacion:
    """Ejecuta las fases disponibles hasta el límite pedido por quien llama."""
    limite = _normalizar_fase(hasta_fase)
    tokens, errores = tokenizar(texto)
    if errores:
        return ResultadoCompilacion("Léxica", tokens=tokens, errores=errores)
    if limite == 1:
        return ResultadoCompilacion("Léxica", tokens=tokens)

    try:
        ast = parsear(tokens)
    except ErrorCompilador as error:
        return ResultadoCompilacion("Sintáctica", tokens=tokens, errores=[error])
    if limite <= 2:
        return ResultadoCompilacion("Sintáctica", tokens=tokens, ast=ast)

    from recetalang.semantico import analizar

    tabla, errores = analizar(ast)
    resultado = ResultadoCompilacion(
        "Semántica", tokens=tokens, ast=ast, errores=errores, simbolos=tabla.como_dict()
    )
    if errores or limite == 3:
        return resultado

    from recetalang.generador import generar

    bytecode = generar(ast)
    resultado.fase = "Generación de código"
    resultado.bytecode = bytecode
    if limite == 4:
        return resultado

    from recetalang.maquina_virtual import ErrorMaquinaVirtual, ejecutar

    try:
        resultado.salida = ejecutar(bytecode)
    except ErrorMaquinaVirtual as error:
        resultado.fase = "Ejecución"
        resultado.errores = [ErrorCompilador(1, 1, str(error), "Ejecución")]
        return resultado
    resultado.fase = "Ejecución"
    return resultado
