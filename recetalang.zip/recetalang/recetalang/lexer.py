"""Analizador léxico manual que recorre el texto carácter por carácter."""

from recetalang.errores import ErrorCompilador
from recetalang.tokens import PALABRAS_RESERVADAS, TipoToken, Token


_SIMBOLOS = {
    "=": TipoToken.IGUAL,
    "+": TipoToken.MAS,
    "-": TipoToken.MENOS,
    "*": TipoToken.POR,
    ">": TipoToken.MAYOR,
    "<": TipoToken.MENOR,
    ",": TipoToken.COMA,
    "(": TipoToken.PAREN_IZQ,
    ")": TipoToken.PAREN_DER,
}


class Lexer:
    """Mantiene el cursor y recopila errores para reportarlos juntos."""

    def __init__(self, texto: str) -> None:
        self.texto = texto
        self.indice = 0
        self.linea = 1
        self.columna = 1
        self.tokens: list[Token] = []
        self.errores: list[ErrorCompilador] = []
        self.linea_con_contenido = False

    def tokenizar(self) -> tuple[list[Token], list[ErrorCompilador]]:
        """Reconoce todas las clases y siempre agrega EOF al final."""
        while not self._terminado():
            caracter = self._actual()
            if caracter in " \t\f":
                self._avanzar()
            elif caracter in "\r\n":
                self._nueva_linea()
            elif caracter == '"':
                self._cadena()
            elif caracter in "0123456789":
                self._entero()
            elif caracter == "_" or caracter.isalpha():
                self._identificador()
            elif caracter == "=" and self._mirar(1) == "=":
                self._agregar(TipoToken.IGUAL_IGUAL, "==", "==")
                self._avanzar()
                self._avanzar()
            elif caracter in _SIMBOLOS:
                self._agregar(_SIMBOLOS[caracter], caracter, caracter)
                self._avanzar()
            else:
                self.errores.append(
                    ErrorCompilador(
                        self.linea,
                        self.columna,
                        f"símbolo no reconocido «{caracter}»",
                        "Léxico",
                    )
                )
                self.linea_con_contenido = True
                self._avanzar()

        if self.linea_con_contenido and self._ultimo_tipo() != TipoToken.NEWLINE:
            self._agregar(TipoToken.NEWLINE, "\n", None)
        self._agregar(TipoToken.EOF, "", None)
        return self.tokens, self.errores

    def _terminado(self) -> bool:
        return self.indice >= len(self.texto)

    def _actual(self) -> str:
        return self.texto[self.indice]

    def _mirar(self, desplazamiento: int) -> str:
        posicion = self.indice + desplazamiento
        return self.texto[posicion] if posicion < len(self.texto) else ""

    def _avanzar(self) -> None:
        self.indice += 1
        self.columna += 1

    def _agregar(
        self, tipo: TipoToken, lexema: str, valor: int | str | None
    ) -> None:
        self.tokens.append(Token(tipo, lexema, valor, self.linea, self.columna))
        if tipo not in {TipoToken.NEWLINE, TipoToken.EOF}:
            self.linea_con_contenido = True

    def _ultimo_tipo(self) -> TipoToken | None:
        return self.tokens[-1].tipo if self.tokens else None

    def _nueva_linea(self) -> None:
        linea, columna = self.linea, self.columna
        if self._actual() == "\r" and self._mirar(1) == "\n":
            self.indice += 2
        else:
            self.indice += 1
        if self._ultimo_tipo() != TipoToken.NEWLINE and self.tokens:
            self.tokens.append(Token(TipoToken.NEWLINE, "\n", None, linea, columna))
        self.linea += 1
        self.columna = 1
        self.linea_con_contenido = False

    def _identificador(self) -> None:
        inicio, linea, columna = self.indice, self.linea, self.columna
        while not self._terminado():
            caracter = self._actual()
            if caracter == "_" or caracter.isalnum():
                self._avanzar()
            else:
                break
        lexema = self.texto[inicio:self.indice]
        tipo = PALABRAS_RESERVADAS.get(lexema, TipoToken.IDENTIFICADOR)
        self.tokens.append(Token(tipo, lexema, lexema, linea, columna))
        self.linea_con_contenido = True

    def _entero(self) -> None:
        inicio, linea, columna = self.indice, self.linea, self.columna
        while not self._terminado() and self._actual() in "0123456789":
            self._avanzar()
        lexema = self.texto[inicio:self.indice]
        self.tokens.append(Token(TipoToken.ENTERO, lexema, int(lexema), linea, columna))
        self.linea_con_contenido = True

    def _cadena(self) -> None:
        linea, columna = self.linea, self.columna
        self._avanzar()
        inicio = self.indice
        while not self._terminado() and self._actual() not in '"\r\n':
            self._avanzar()
        if self._terminado() or self._actual() in "\r\n":
            self.errores.append(
                ErrorCompilador(
                    linea, columna, "cadena sin comilla de cierre", "Léxico"
                )
            )
            self.linea_con_contenido = True
            return
        valor = self.texto[inicio:self.indice]
        self._avanzar()
        lexema = f'"{valor}"'
        self.tokens.append(Token(TipoToken.CADENA, lexema, valor, linea, columna))
        self.linea_con_contenido = True


def tokenizar(texto: str) -> tuple[list[Token], list[ErrorCompilador]]:
    """Función pública del lexer; conserva errores sin detener el recorrido."""
    return Lexer(texto).tokenizar()
