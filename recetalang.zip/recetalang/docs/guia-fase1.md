# Guía de la Fase 1 — Cimientos y diseño

## Archivos y propósito

### Archivos raíz

- `README.md`: presenta el lenguaje y el estado gradual del proyecto.
- `.gitignore`: excluye bytecode de Python, cachés y entornos virtuales locales.
- `BITACORA.md`: registra integrantes, decisiones D1–D13 y uso de IA pendiente de atribución.

### Paquete `recetalang/`

- `__init__.py`: identifica el directorio como paquete importable.
- `__main__.py`: reservará el punto de entrada de `python -m recetalang`.
- `errores.py`: reservará los errores con fase y posición de origen.
- `tokens.py`: reservará las clases y categorías de tokens.
- `lexer.py`: reservará el recorrido carácter por carácter del texto.
- `ast_nodos.py`: reservará las estructuras de datos del árbol sintáctico.
- `parser.py`: reservará el análisis sintáctico de descenso recursivo.
- `tabla_simbolos.py`: reservará el almacenamiento de variables y valores conocidos.
- `semantico.py`: reservará la validación de variables y reglas del recetario.
- `generador.py`: reservará la traducción del AST a instrucciones de bytecode.
- `maquina_virtual.py`: reservará la ejecución del bytecode y el registro de receta.
- `compilador.py`: reservará la coordinación de las fases del compilador.

### Documentación y gramática

- `docs/especificacion.md`: reúne las reglas normativas de RecetaLang para consulta del grupo.
- `docs/fases-del-compilador.md`: explica las cuatro fases y el flujo de datos.
- `docs/reparto.md`: reparte contribuciones y commits por fase de forma rotativa.
- `gramatica/recetalang.ebnf`: contiene un marcador para completar la gramática en la Fase 3.
- `docs/guia-fase1.md`: explica los artefactos de esta fase y prepara preguntas de defensa.
- `docs/commits-sugeridos-fase1.md`: propone tres bloques de commit sin atribuirlos ni ejecutarlos.

### Ejemplos y verificación

- `ejemplos/01_preparacion_basica.receta`: secuencia sencilla con dos ingredientes.
- `ejemplos/02_cantidades_calculadas.receta`: variables y las tres operaciones aritméticas.
- `ejemplos/03_repeticiones_y_decisiones.receta`: ramas, repetición y comparadores.
- `ejemplos/04_error_lexico.receta`: contiene `@` en la columna 27.
- `ejemplos/05_error_sintactico.receta`: deja abierto un bloque hasta EOF.
- `ejemplos/06_error_semantico.receta`: usa `cantidad` antes de definirla.
- `ejemplos/07_anidado_valido.receta`: cambia una variable dentro de un bucle con condición anidada.
- `ejemplos/08_error_sintactico_sin_sino.receta`: omite el `sino` obligatorio.
- `ejemplos/09_error_regla_repetir.receta`: inicia una repetición con valor negativo.
- `ejemplos/ESPERADO.md`: fija registros y mensajes para comparar futuras fases.
- `ejemplos/extra/*.receta`: guarda cinco casos semánticos adicionales para fases posteriores.
- `pruebas/.gitkeep` y `resultados/.gitkeep`: preservan directorios que recibirán archivos luego.
- `pruebas/__init__.py` y `pruebas/test_fase1.py`: habilitan descubrimiento de `unittest` y comprueban cantidad de ejemplos, saltos finales y posiciones de referencia.
- `tools/empaquetar.py`: crea un zip con raíz `recetalang/` y excluye repositorio, cachés y entregas.

## Preguntas probables del profesor

1. **¿Por qué se separan los archivos del compilador?** Cada módulo representa una responsabilidad y facilita explicar o cambiar una fase sin mezclarla con las demás.
2. **¿Qué diferencia hay entre un error léxico y uno sintáctico?** El léxico no reconoce un carácter; el sintáctico reconoce los tokens, pero no su orden.
3. **¿Por qué hay un `ESPERADO.md`?** Permite comparar de forma reproducible la salida de la ejecución y los mensajes de error.
4. **¿Qué representa D1?** Define dónde se ubica EOF para que los errores al final del archivo tengan línea y columna deterministas.
5. **¿Qué hace el empaquetador?** Construye un zip autocontenido del proyecto sin incluir Git, cachés ni entregas previas.
