# Commits sugeridos — Fase 2

Cada bloque debe registrarse con la cuenta personal de quien lo realiza.

## Juan Sebastian Palacios Encarnación

```text
feat(lexer): definir tokens y errores con posición
```

Incluye `recetalang/tokens.py` y `recetalang/errores.py`.

## Yeiner Palacios Mena

```text
feat(lexer): reconocer tokens y acumular errores léxicos
```

Incluye `recetalang/lexer.py` y el manejo manual de líneas y columnas.

## Carlos Daniel Martínez Palacios

```text
test(lexer): cubrir tokens, errores y posiciones
```

Incluye `recetalang/__main__.py`, `pruebas/test_lexer.py` y `docs/guia-fase2.md`.
