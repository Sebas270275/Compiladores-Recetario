# Reglas semánticas de RecetaLang

Estas comprobaciones ocurren después de que el programa tiene una estructura sintáctica válida. Los errores se reúnen y se ordenan por línea y columna; si aparece alguno, el compilador no genera bytecode.

## Variable definida antes de usarse

**Motivación:** cada expresión necesita un entero proveniente de una asignación anterior. En ramas, solo sobrevive una definición presente en ambas alternativas; en bucles, el cuerpo se analiza con valores desconocidos para variables que se reasignan.

- Inválido: `agregar "arroz", cantidad, "g"` sin asignar `cantidad`.
- Válido: `cantidad = 10` seguido de `agregar "arroz", cantidad, "g"`.
- Mensaje: `Línea 1, columna 18: la variable «cantidad» no está definida`.

## R1 — Cantidad positiva

**Motivación:** registrar cero o una cantidad negativa no representa un ingrediente utilizable. Se comprueba cuando el valor puede conocerse estáticamente.

- Inválido: `agregar "harina",-10,"g"`.
- Válido: `agregar "harina",10,"g"`.
- Mensaje: `Línea 1, columna 18: [R1] la cantidad debe ser mayor que cero (valor: -10)`.

## R2 — Tiempo positivo

**Motivación:** mezclar y cocinar requieren una duración mayor que cero.

- Inválido: con un ingrediente agregado antes, `cocinar -5`.
- Válido: con un ingrediente agregado antes, `cocinar 5`.
- Mensaje: `Línea 2, columna 9: [R2] el tiempo debe ser mayor que cero (valor: -5)`.

## R3 — Repetición positiva

**Motivación:** una repetición de cero o menos veces no ejecuta el bloque, mientras que el modelo estático de RecetaLang considera que un bloque válido corre al menos una vez.

- Inválido: `repetir -2 veces`.
- Válido: `repetir 2 veces`.
- Mensaje: `Línea 2, columna 9: [R3] la repetición debe ser mayor que cero (valor: -2)`.

## R4 — Preparación iniciada

**Motivación:** mezclar o cocinar sin ingredientes no representa una preparación. En un condicional, el requisito se conserva después solo si las dos ramas agregan algo; en un bucle cuenta el cuerpo porque R3 exige una iteración positiva.

- Inválido: `cocinar 10` antes de cualquier `agregar`.
- Válido: `agregar "arroz",10,"g"` y luego `cocinar 10`.
- Mensaje: `Línea 1, columna 1: [R4] se debe agregar al menos un ingrediente antes de mezclar o cocinar`.

## U1 — Unidad admitida

**Motivación:** esta versión registra cantidades en gramos o mililitros; otros textos no representan unidades soportadas.

- Inválido: `agregar "harina", 5, "kg"`.
- Válido: `agregar "harina", 5, "g"`.
- Mensaje: `Línea 1, columna 23: [U1] unidad «kg» no admitida (use «g» o «ml»)`.

Cuando un valor de cantidad, tiempo o repetición es desconocido, R1, R2 y R3 no se informan: así el análisis estático evita falsos positivos.
