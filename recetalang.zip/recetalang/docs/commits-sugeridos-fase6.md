# Commits sugeridos — Fase 6

## Juan Sebastian Palacios Encarnación

```text
feat(semantic): validar cantidades, tiempos y repeticiones
```

Incluye R1, R2 y R3 en `recetalang/semantico.py`.

## Yeiner Palacios Mena

```text
feat(semantic): validar preparación y unidades del recetario
```

Incluye R4, U1 y los cambios de estado de ramas y bucles.

## Carlos Daniel Martínez Palacios

```text
test(semantic): cubrir reglas del dominio
```

Incluye `pruebas/test_reglas.py`, `docs/reglas-semanticas.md` y la guía de fase.
