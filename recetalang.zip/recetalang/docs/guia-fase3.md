# Guía de la Fase 3 — Gramática y parser

## Archivos nuevos o ampliados

- `gramatica/recetalang.ebnf` fija las producciones que el parser acepta.
- `recetalang/ast_nodos.py` define nodos simples con posiciones para expresiones e instrucciones.
- `recetalang/parser.py` implementa una función de descenso recursivo por regla y se detiene en el primer error.
- `recetalang/__main__.py` permite inspeccionar el árbol con `--ast`.
- `pruebas/test_parser.py` comprueba precedencia, paréntesis, signo unario, anidamiento y mensajes de error.
- `docs/gramatica.md` explica las reglas y muestra el árbol del ejemplo 03.

## Preguntas probables

1. **¿Qué hace recursivo al parser?** Las reglas de bloques y expresiones llaman a métodos que vuelven a analizar las mismas clases de construcción.
2. **¿Cómo se da prioridad a `*`?** `_expresion` delega en `_termino`, y este agrupa multiplicaciones antes de devolver el resultado.
3. **¿Cómo se sabe si `-` es unario?** Si aparece al inicio de un factor, `_factor` lo interpreta como signo; en `_expresion` puede ser resta binaria.
4. **¿Por qué `sino` no cierra un bloque?** Divide las dos ramas del condicional; solo el `fin` correspondiente cierra el condicional completo.
5. **¿Qué contiene el AST?** Nodos tipados con los valores y la posición de las construcciones del programa.
