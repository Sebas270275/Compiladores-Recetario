# Plan de commits por fase

Los mensajes son propuestas pequeñas, no commits ya realizados. Cada integrante debe usar su propia identidad Git. El reparto de bloques sigue `docs/reparto.md`.

| Fase | Integrante | Bloque sugerido | Mensaje sugerido |
|---|---|---|---|
| 1 | Juan Sebastian Palacios Encarnación | Estructura y documentación base | `docs: preparar estructura y documentación base de RecetaLang` |
| 1 | Yeiner Palacios Mena | Ejemplos y expectativas | `docs: añadir programas de ejemplo y resultados esperados` |
| 1 | Carlos Daniel Martínez Palacios | Empaquetador y pruebas iniciales | `build: añadir empaquetador y guía de la fase 1` |
| 2 | Juan Sebastian Palacios Encarnación | Tipos y errores | `feat(lexer): definir tokens y errores con posición` |
| 2 | Yeiner Palacios Mena | Recorrido del lexer | `feat(lexer): reconocer tokens y acumular errores léxicos` |
| 2 | Carlos Daniel Martínez Palacios | CLI y pruebas | `test(lexer): cubrir tokens, errores y posiciones` |
| 3 | Juan Sebastian Palacios Encarnación | EBNF y documentación | `docs(grammar): documentar gramática EBNF y árbol de ejemplo` |
| 3 | Yeiner Palacios Mena | AST y parser | `feat(parser): construir AST con descenso recursivo` |
| 3 | Carlos Daniel Martínez Palacios | Pruebas y guía | `test(parser): verificar expresiones, bloques y errores` |
| 4 | Juan Sebastian Palacios Encarnación | Orquestación de fases | `feat(compiler): encadenar lexer y parser con corte por fase` |
| 4 | Yeiner Palacios Mena | Reporte automatizado | `test(integration): generar reporte de los nueve ejemplos` |
| 4 | Carlos Daniel Martínez Palacios | Informe de Actividad 5 | `docs: redactar informe de Actividad 5` |
| 5 | Juan Sebastian Palacios Encarnación | Tabla y fusión de ramas | `feat(semantic): implementar tabla de símbolos y fusión de ramas` |
| 5 | Yeiner Palacios Mena | Valores y expresiones | `feat(semantic): validar variables y plegar expresiones conocidas` |
| 5 | Carlos Daniel Martínez Palacios | Casos de variables | `test(semantic): cubrir variables, ramas y bucles` |
| 6 | Juan Sebastian Palacios Encarnación | Reglas numéricas R1–R3 | `feat(semantic): validar cantidades, tiempos y repeticiones` |
| 6 | Yeiner Palacios Mena | R4 y U1 | `feat(semantic): validar preparación y unidades del recetario` |
| 6 | Carlos Daniel Martínez Palacios | Pruebas de reglas | `test(semantic): cubrir reglas del dominio` |
| 7 | Juan Sebastian Palacios Encarnación | Generador | `feat(codegen): traducir expresiones y control de flujo a bytecode` |
| 7 | Yeiner Palacios Mena | Máquina virtual | `feat(vm): ejecutar bytecode y registrar instrucciones culinarias` |
| 7 | Carlos Daniel Martínez Palacios | Pruebas y guía de VM | `test(vm): comparar salidas y probar bucles y saltos` |
| 8 | Juan Sebastian Palacios Encarnación | README y decisiones | `docs: cerrar README y borrador de decisiones` |
| 8 | Yeiner Palacios Mena | Defensa y ejercicios | `docs(defensa): preparar mapa y ejercicios de extensión` |
| 8 | Carlos Daniel Martínez Palacios | Informe, bitácora y paquetes | `build: generar informe final y paquetes del compilador` |
