# Commits sugeridos — Fase 4

## Juan Sebastian Palacios Encarnación

```text
feat(compiler): encadenar lexer y parser con corte por fase
```

Incluye `recetalang/compilador.py` y pruebas de integración.

## Yeiner Palacios Mena

```text
test(integration): generar reporte de los nueve ejemplos
```

Incluye `pruebas/ejecutar_pruebas.py` y `resultados/resultados_actividad5.txt` generado por el script.

## Carlos Daniel Martínez Palacios

```text
docs: redactar informe de Actividad 5
```

Incluye `docs/informe-actividad5.md` y la guía de la fase.
