# Guía de la Fase 4 — Integración léxica y sintáctica

## Archivos nuevos o ampliados

- `recetalang/compilador.py` detiene el flujo si falla el lexer o el parser y devuelve el estado de la fase.
- `pruebas/test_integracion_lexico_sintactico.py` prueba que un error léxico impida ejecutar el parser.
- `pruebas/ejecutar_pruebas.py` lee expectativas, procesa nueve ejemplos y genera el reporte reproducible.
- `resultados/resultados_actividad5.txt` contiene la salida generada para la entrega de Actividad 5.
- `docs/informe-actividad5.md` resume el funcionamiento y la verificación de las dos fases.

## Preguntas probables

1. **¿Cómo decide el orquestador qué fase ejecutar?** Recibe un límite y retorna al detectar el primer error o al alcanzar ese límite.
2. **¿Qué ocurre si el lexer informa errores?** El orquestador retorna esos errores sin invocar el parser.
3. **¿Por qué 06 y 09 pasan sintaxis?** Sus tokens y bloques están bien formados; sus problemas requieren análisis semántico.
4. **¿Cómo se genera el archivo de resultados?** El script recorre los `.receta`, compara fase o mensaje y escribe el resumen.
5. **¿Qué evita que el reporte sea escrito a mano?** El archivo solo se crea como resultado de `ejecutar_pruebas.py`.
