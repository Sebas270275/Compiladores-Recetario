# Informe de Actividad 5 — análisis léxico y sintáctico

El lexer de RecetaLang recorre el archivo carácter por carácter y produce tokens con su tipo, lexema, valor y posición. Reconoce las palabras reservadas, identificadores Unicode, enteros, cadenas, operadores, delimitadores, saltos de línea y EOF. Si hay símbolos desconocidos o cadenas sin cerrar, reúne los errores y no entrega el programa a la fase sintáctica.

El parser toma esos tokens y aplica una gramática de descenso recursivo. Cada método implementa una regla, construye nodos del AST y aplica la prioridad de multiplicación sobre suma y resta. También verifica los bloques `repetir` y `si/sino`; si falta un cierre o una palabra obligatoria, informa el primer error sintáctico.

Los mensajes muestran línea y columna desde 1. EOF se ubica después del último carácter, por lo que un archivo con tres líneas y salto final termina en la línea 4, columna 1. La CLI permite consultar tokens y AST antes de completar la ejecución del compilador.

La integración se probó con `python -m unittest discover` y con `python pruebas/ejecutar_pruebas.py`. El segundo comando procesa los nueve programas y escribe `resultados/resultados_actividad5.txt`, comparando errores exactos y distinguiendo los errores semánticos que se detectarán en fases posteriores.
