# Gramática y árbol sintáctico

El lexer entrega tokens con posiciones; el parser aplica las reglas de `gramatica/recetalang.ebnf` y crea los nodos dataclass de `recetalang/ast_nodos.py`. Cada método del parser corresponde a una regla importante, lo que permite seguir el análisis paso a paso.

## Reglas principales

- **programa:** acepta cero o más instrucciones y líneas vacías hasta EOF. Ejemplo: `harina = 200`.
- **sentencia:** selecciona asignación, agregar, mezclar, cocinar, repetir o condicional según el primer token.
- **asignacion:** un identificador, `=`, una expresión y fin de línea. Ejemplo: `agua = 100 + 50`.
- **agregar:** una cadena de ingrediente, coma, expresión de cantidad, coma, cadena de unidad. Ejemplo: `agregar "arroz", 300, "g"`.
- **mezclar/cocinar:** palabra reservada seguida de una expresión y fin de línea. Ejemplo: `mezclar 3`.
- **repetir:** expresión de veces, palabra `veces`, salto de línea, bloque y `fin`.
- **condicional:** comparación, `entonces`, bloque verdadero, `sino`, bloque falso y `fin`.
- **bloque:** secuencia de instrucciones que termina al encontrar `fin`; dentro de la primera rama de `si` también termina ante `sino`.
- **comparador:** únicamente `>`, `<` o `==`.
- **expr/termino/factor:** implementan prioridad de `*`, después `+`/`-`, paréntesis y menos unario.
- **fin_linea:** es `NEWLINE` o `EOF`, por lo que el último comando puede terminar justo al final del archivo.

## Árbol del programa 03

Representación abreviada, omitiendo las posiciones para facilitar la lectura:

```text
Programa
├── Asignacion(porciones, Numero(4))
├── Condicional(Comparacion(porciones, >, 2))
│   ├── rama_si: Agregar(arroz, 300, g)
│   └── rama_sino: Agregar(arroz, 150, g)
├── Repetir(Numero(2))
│   └── cuerpo: Mezclar(Numero(1))
├── Condicional(Comparacion(porciones, <, 5))
│   ├── rama_si: Agregar(agua, 500, ml)
│   └── rama_sino: Agregar(agua, 700, ml)
└── Condicional(Comparacion(porciones, ==, 4))
    ├── rama_si: Cocinar(Numero(25))
    └── rama_sino: Cocinar(Numero(15))
```
