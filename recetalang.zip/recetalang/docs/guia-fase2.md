# Guía de la Fase 2 — Analizador léxico

## Archivos nuevos o ampliados

- `recetalang/tokens.py` define cada tipo de token y guarda lexema, valor y posición.
- `recetalang/errores.py` presenta una excepción con fase, línea, columna y mensaje.
- `recetalang/lexer.py` recorre caracteres, reconoce palabras, números, cadenas y símbolos, y recopila errores sin detenerse.
- `recetalang/__main__.py` ofrece la opción `--tokens` y muestra una tabla de posiciones.
- `pruebas/test_lexer.py` verifica categorías, Unicode, errores, CRLF, EOF y los nueve ejemplos.

## Preguntas probables

1. **¿Por qué mirar el carácter siguiente tras `=`?** Para distinguir asignación (`=`) de comparación (`==`) en el propio lexer.
2. **¿Por qué el lexer sigue tras encontrar `@`?** La decisión D2 pide reunir todos los errores léxicos en una pasada.
3. **¿Cómo se identifica una palabra reservada?** Se lee el identificador completo y se consulta el diccionario de reservadas.
4. **¿Qué significa la posición de EOF?** Señala el carácter que sigue al archivo; con salto final queda en la línea siguiente, columna 1.
5. **¿Por qué las líneas vacías no generan muchos tokens?** Se colapsan en un solo separador para que el parser no trate cada renglón vacío como una instrucción.
