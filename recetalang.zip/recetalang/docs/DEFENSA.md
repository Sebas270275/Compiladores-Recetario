# Guía para la defensa de RecetaLang

## Mapa de preguntas a código

| Si preguntan por… | Archivo | Función o elemento |
|---|---|---|
| Tipos de token y reservadas | `recetalang/tokens.py` | `TipoToken`, `PALABRAS_RESERVADAS`, `Token` |
| Recorrido carácter por carácter | `recetalang/lexer.py` | `Lexer.tokenizar`, `_identificador`, `_cadena` |
| Columnas y errores | `recetalang/errores.py` | `ErrorCompilador.formato` |
| Inicio del programa | `recetalang/parser.py` | `Parser._programa` |
| Instrucciones y bloques | `recetalang/parser.py` | `_sentencia`, `_repetir`, `_condicional`, `_bloque` |
| Prioridad de operaciones | `recetalang/parser.py` | `_expresion`, `_termino`, `_factor` |
| Nodos del AST | `recetalang/ast_nodos.py` | dataclasses `Programa`, `Condicional`, `OperacionBinaria`, etc. |
| Variables y valores conocidos | `recetalang/tabla_simbolos.py` | `definir`, `copiar`, `fusionar_ramas` |
| Validación semántica | `recetalang/semantico.py` | `AnalizadorSemantico._evaluar`, `_visitar_condicional`, `_visitar_repetir` |
| Generación de bytecode | `recetalang/generador.py` | `_sentencia`, `_condicional`, `_repetir` |
| Ejecución y límite de pasos | `recetalang/maquina_virtual.py` | `ejecutar` |
| Orden de fases | `recetalang/compilador.py` | `compilar` |
| Opciones de consola | `recetalang/__main__.py` | `main` |

## Cambios pequeños de 10 minutos

### (a) Agregar `hornear tiempo` — dificultad media

1. En `recetalang/tokens.py`, agregar `HORNEAR` y la palabra reservada; el lexer ya consulta ese diccionario.
2. En `recetalang/ast_nodos.py`, agregar `Hornear`; en `recetalang/parser.py`, reconocer la instrucción y construir el nodo.
3. En `recetalang/semantico.py`, validar tiempo positivo y R4 como para `cocinar`; en `recetalang/generador.py` y `recetalang/maquina_virtual.py`, emitir y ejecutar `HORNEAR`.
4. Actualizar `gramatica/recetalang.ebnf`, `docs/especificacion.md`, pruebas y `ejemplos/ESPERADO.md`.

### (b) Agregar `%` — dificultad media

1. En `tokens.py` y `lexer.py`, declarar y reconocer `MODULO` como operador.
2. En `gramatica/recetalang.ebnf` y `parser.py`, incluirlo al nivel de multiplicación en `_termino`.
3. En `semantico.py`, plegar `izquierda % derecha`; definir y probar qué pasa con divisor cero antes de usarlo.
4. En `generador.py` y `maquina_virtual.py`, agregar `MOD`; sumar ejemplos y pruebas.

### (c) Agregar `>=` — dificultad media

1. En `tokens.py`, agregar `MAYOR_IGUAL`; en `lexer.py`, reconocer `>=` con anticipación de dos caracteres.
2. En `parser.py` y la gramática, aceptarlo como comparador; en `generador.py`, emitir `GE`.
3. En `maquina_virtual.py`, evaluar `GE`; cubrir verdadero, falso y prioridad sobre `>` con pruebas.

### (d) Agregar comentarios `#` — dificultad baja

1. En `recetalang/lexer.py`, al encontrar `#`, avanzar hasta el salto de línea sin consumirlo.
2. Probar comentario solo, comentario después de una instrucción y `#` dentro de una cadena.
3. Actualizar `docs/especificacion.md`, EBNF si corresponde, README y BITACORA (D13).

### (e) Aceptar la unidad `"kg"` — dificultad baja

1. En `recetalang/semantico.py`, agregar `kg` al conjunto de unidades aceptadas en U1.
2. Añadir una prueba válida y actualizar `pruebas/test_reglas.py`.
3. Cambiar `docs/especificacion.md`, `docs/reglas-semanticas.md` y los resultados esperados.

### (f) Prohibir mezclar más de 60 minutos — dificultad baja

1. En `recetalang/semantico.py`, dentro de `_visitar_accion`, revisar solo `Mezclar` cuyo tiempo conocido sea mayor que 60.
2. Informar una nueva regla, por ejemplo R5, en la posición inicial del tiempo.
3. Añadir casos 60, 61 y valor desconocido en `pruebas/test_reglas.py`; documentar la regla.

### (g) Hacer opcional `sino` — dificultad media

1. En `gramatica/recetalang.ebnf` y `parser.py`, permitir que `fin` aparezca después de la rama `si`.
2. En `recetalang/semantico.py`, analizar la rama ausente como una copia sin cambios del estado inicial antes de fusionar.
3. Probar variables definidas solo en la rama existente y actualizar la guía de sintaxis.

### (h) Agregar `mientras` — dificultad alta

1. Añadir palabra reservada y nodo con condición y cuerpo; reconocer `mientras ... hacer ... fin` en lexer, AST y parser.
2. En `recetalang/semantico.py`, tratar asignaciones del ciclo como desconocidas y no afirmar que el ciclo termina o se ejecuta.
3. En `recetalang/generador.py`, generar condición, `JZ` al final y salto al comienzo; probarlo en la VM con su límite de pasos.
4. Actualizar EBNF, especificación, pruebas, ejemplos y defensa.

## 20 preguntas probables

1. **¿Qué hace el lexer?** Convierte caracteres en tokens con posición.
2. **¿Por qué es manual?** Para mostrar claramente cómo se reconoce cada carácter sin generadores.
3. **¿Cómo diferencia `=` de `==`?** Mira el carácter siguiente antes de emitir el token.
4. **¿Las palabras reservadas distinguen mayúsculas?** Sí; solo las formas minúsculas son reservadas.
5. **¿Se admiten identificadores con ñ?** Sí, se usan las reglas Unicode de letras.
6. **¿Qué representa EOF?** La posición justo después del último carácter.
7. **¿Qué pasa si hay varios errores léxicos?** Se reúnen y no se ejecuta el parser.
8. **¿Cómo se reconoce una asignación?** Identificador, `=`, expresión y fin de línea.
9. **¿Qué significa descenso recursivo?** Cada regla se implementa con una función que puede llamar a otras reglas.
10. **¿Qué prioridad tienen los operadores?** `*` antes que `+` y `-`; el mismo nivel se evalúa de izquierda a derecha.
11. **¿Cómo se representa `-3`?** Como un nodo unario sobre el número 3.
12. **¿Qué hace `fin`?** Cierra el bloque abierto más cercano.
13. **¿Por qué `sino` es obligatorio?** Así lo define esta versión de la gramática.
14. **¿Qué es el AST?** Una representación de instrucciones y expresiones como nodos tipados.
15. **¿Qué contiene la tabla de símbolos?** Cada nombre definido y su valor conocido o desconocido.
16. **¿Por qué analizar ambas ramas?** El compilador no ejecuta la condición para decidir una rama estática.
17. **¿Por qué un bucle puede volver un valor desconocido?** El número de cambios depende de sus iteraciones.
18. **¿Qué valida R4?** Que exista un ingrediente agregado antes de mezclar o cocinar.
19. **¿Qué es bytecode aquí?** Una lista pequeña de operaciones para una máquina virtual de pila.
20. **¿Cómo se protege la VM?** Detiene la ejecución al superar 100 000 pasos.
