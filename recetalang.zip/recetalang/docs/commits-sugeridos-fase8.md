# Commits sugeridos — Fase 8

## Juan Sebastian Palacios Encarnación

```text
docs: cerrar README y borrador de decisiones
```

Incluye `README.md` y `docs/dificultades-y-decisiones.md`.

## Yeiner Palacios Mena

```text
docs(defensa): preparar mapa y ejercicios de extensión
```

Incluye `docs/DEFENSA.md`, la guía de fase y los ajustes de ejemplos.

## Carlos Daniel Martínez Palacios

```text
build: generar informe final y paquetes del compilador
```

Incluye el ejecutor integrado, reportes, empaquetador, bitácora y plan consolidado.
