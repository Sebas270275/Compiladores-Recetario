# Commits sugeridos — Fase 1

Realizar los commits con la cuenta Git individual indicada en el reparto; los nombres solo sugieren quién prepara cada bloque y no afirman que el commit ya exista.

## Bloque 1 — Juan Sebastian Palacios Encarnación

```text
docs: preparar estructura y documentación base de RecetaLang
```

Incluye `README.md`, `.gitignore`, `BITACORA.md`, especificación, fases y reparto.

## Bloque 2 — Yeiner Palacios Mena

```text
docs: añadir programas de ejemplo y resultados esperados
```

Incluye los nueve ejemplos, `ejemplos/extra/` y `ejemplos/ESPERADO.md`.

## Bloque 3 — Carlos Daniel Martínez Palacios

```text
build: añadir empaquetador y guía de la fase 1
```

Incluye módulos vacíos del paquete, gramática pendiente, pruebas de aceptación de los cimientos, guía y `tools/empaquetar.py`.
