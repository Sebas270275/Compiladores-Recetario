# Commits sugeridos — Fase 3

## Juan Sebastian Palacios Encarnación

```text
docs(grammar): documentar gramática EBNF y árbol de ejemplo
```

Incluye `gramatica/recetalang.ebnf` y `docs/gramatica.md`.

## Yeiner Palacios Mena

```text
feat(parser): construir AST con descenso recursivo
```

Incluye `recetalang/ast_nodos.py` y `recetalang/parser.py`.

## Carlos Daniel Martínez Palacios

```text
test(parser): verificar expresiones, bloques y errores
```

Incluye `pruebas/test_parser.py`, la opción `--ast` y la guía de fase.
