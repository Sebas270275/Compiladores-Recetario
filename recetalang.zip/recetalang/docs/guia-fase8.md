# Guía de la Fase 8 — Integración y defensa

## Archivos nuevos o ampliados

- `pruebas/ejecutar_pruebas.py` recorre ejemplos principales y extra y genera los dos reportes.
- `resultados/resultados_final.txt` presenta fase final, salida o error y coincidencia para cada caso.
- `docs/dificultades-y-decisiones.md` resume los retos como borrador para que el grupo lo reescriba.
- `docs/DEFENSA.md` conecta preguntas con código, propone ocho cambios breves y reúne veinte preguntas.
- `docs/plan-de-commits.md` organiza los commits sugeridos por integrante para las ocho fases.
- `README.md` documenta instalación, ejecución, pruebas, estructura y salida.
- `ejemplos/actividad3/` contiene el conjunto de entrega de tres programas válidos y tres inválidos, con expectativas.
- `tools/empaquetar.py` crea el zip de fase y el paquete completo con las mismas exclusiones.

## Preguntas probables

1. **¿Cómo se comprueba el resultado final?** El ejecutor compara salidas y mensajes de los catorce casos con las expectativas.
2. **¿Qué contiene el zip final?** El proyecto bajo una raíz `recetalang/`, sin Git, cachés ni entregas anidadas.
3. **¿Por qué el texto de dificultades es borrador?** Para que los integrantes expliquen decisiones con sus propias palabras.
4. **¿Cómo encontrar dónde cambiar una regla?** Usar el mapa de la defensa para ubicar archivo y función.
5. **¿Por qué sugerir commits pequeños?** Facilita que cada integrante registre su propia contribución.
