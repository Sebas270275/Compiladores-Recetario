# Guía de la Fase 6 — Reglas semánticas del recetario

## Archivos nuevos o ampliados

- `recetalang/semantico.py` aplica R1, R2, R3, R4 y U1 además de revisar variables.
- `docs/reglas-semanticas.md` explica motivación, caso válido, caso inválido y mensaje de cada regla.
- `pruebas/test_reglas.py` comprueba reglas conocidas, valores desconocidos y flujo de ingredientes.
- `BITACORA.md` registra esta etapa como una actividad asistida que el grupo debe revisar.

## Preguntas probables

1. **¿Cuándo se revisa R1, R2 o R3?** Cuando el análisis conoce el entero; si es desconocido, no adivina un resultado.
2. **¿Qué posición usa R3?** El primer carácter de la expresión que fija las iteraciones.
3. **¿Por qué U1 es semántica?** `"kg"` es una cadena léxicamente válida; solo el dominio determina que no se acepta.
4. **¿Cómo se mantiene R4 en un `si`?** Después del `si` se exige que el ingrediente exista en ambas ramas.
5. **¿Cuenta un agregado dentro de repetir?** Sí, porque el modelo exige que una repetición válida ocurra al menos una vez.
