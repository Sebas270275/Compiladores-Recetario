# Commits sugeridos — Fase 7

## Juan Sebastian Palacios Encarnación

```text
feat(codegen): traducir expresiones y control de flujo a bytecode
```

Incluye `recetalang/generador.py`.

## Yeiner Palacios Mena

```text
feat(vm): ejecutar bytecode y registrar instrucciones culinarias
```

Incluye `recetalang/maquina_virtual.py` y la integración en el compilador.

## Carlos Daniel Martínez Palacios

```text
test(vm): comparar salidas y probar bucles y saltos
```

Incluye pruebas, opciones CLI de bytecode y documentación de generación.
