# RecetaLang — especificación del lenguaje

## 1. Instrucciones del dominio

| Instrucción | Forma | Significado |
|---|---|---|
| `agregar` | `agregar "ingrediente", cantidad, "unidad"` | Registra un ingrediente, una cantidad expresada numéricamente y una unidad (`"g"` o `"ml"`). |
| `mezclar` | `mezclar tiempo` | Mezcla durante el tiempo indicado, en minutos. |
| `cocinar` | `cocinar tiempo` | Cocina durante el tiempo indicado, en minutos. |

## 2. Variables, expresiones y control

- Las variables almacenan enteros. Se asignan con `identificador = expresión` y pueden reasignarse.
- Los operadores aritméticos son `+`, `-` y `*`. La multiplicación tiene mayor prioridad; suma y resta comparten prioridad y se resuelven de izquierda a derecha. Se permiten paréntesis y menos unario.
- En condiciones se permiten los comparadores `>`, `<` y `==`.
- La repetición usa `repetir expresión veces`, un bloque de instrucciones y `fin`.
- La condición usa `si expresión comparador expresión entonces`, un bloque, `sino`, otro bloque y `fin`. `sino` es obligatorio.
- Los bloques pueden anidarse. Cada `fin` cierra el bloque abierto más cercano; `sino` separa ramas y no cierra el bloque.
- Cada instrucción ocupa una línea. Se ignoran las líneas vacías y la indentación no afecta el significado.

## 3. Tokens

| Clase | Regla |
|---|---|
| Palabras reservadas | `agregar mezclar cocinar repetir veces si entonces sino fin`, escritas en minúscula. |
| Identificador | Letra Unicode o `_` inicial; luego letras Unicode, dígitos o `_`. Distingue mayúsculas y minúsculas. |
| Entero | Uno o más dígitos `0`–`9`. |
| Cadena | Texto entre comillas dobles, en una sola línea. |
| Operadores | `=`, `+`, `-`, `*`, `>`, `<`, `==`. |
| Delimitadores | `,`, `(`, `)`. |
| Fin de línea | Token `NEWLINE`, que separa instrucciones. |
| Fin de archivo | Token `EOF`. |

Cualquier otro símbolo (por ejemplo, `@`) produce un error léxico. Una cadena sin comilla de cierre también produce un error léxico.

## 4. Reglas semánticas

Toda variable debe estar definida antes de usarse.

| Código | Regla | Ejemplo inválido |
|---|---|---|
| R1 | La cantidad de `agregar` debe ser mayor que cero. | `agregar "harina", -10, "g"` |
| R2 | El tiempo de `mezclar` y `cocinar` debe ser mayor que cero. | `cocinar -5` |
| R3 | La expresión de `repetir` debe ser mayor que cero. | `repetir -2 veces` |
| R4 | Antes de `mezclar` o `cocinar` debe haberse ejecutado al menos un `agregar`. | `cocinar 10` como primera instrucción |
| U1 | La unidad de `agregar` debe ser `"g"` o `"ml"`. | `agregar "harina", 5, "kg"` |

## 5. Comportamiento estático acordado

- El análisis semántico conserva para cada variable su valor entero conocido o `None` si no se conoce; solo evalúa por plegado las expresiones cuyos operandos son conocidos.
- R1, R2 y R3 solo se comprueban cuando el valor es conocido. Si la expresión es desconocida, no se informa un falso positivo.
- Se analizan las dos ramas de `si` con copias de la tabla. Una variable queda definida después solo si existe en ambas ramas; su valor se conserva solo si coincide. R4 se conserva solo si se cumple en ambas ramas.
- Dado que R3 requiere una o más iteraciones, las asignaciones del cuerpo de `repetir` quedan con valor desconocido antes de analizar el cuerpo; definiciones y agregados del cuerpo cuentan al salir del bucle.
- Se admiten letras Unicode en identificadores. Las palabras reservadas no pueden usarse como identificadores.
- El nombre del ingrediente acepta cualquier contenido de cadena. La unidad se valida semánticamente.
- Los mensajes de R1, R2 y R3 incluyen código de regla y valor; la columna señala el inicio de la expresión infractora.
- Esta versión no incluye comentarios.

## 6. Salida de ejecución

El compilador producirá una lista de comandos de bajo nivel y una máquina virtual que registra acciones con este formato:

```text
AGREGAR(ingrediente=harina, cantidad=200, unidad=g)
AGREGAR(ingrediente=leche, cantidad=150, unidad=ml)
MEZCLAR(minutos=3)
COCINAR(minutos=25)
```
