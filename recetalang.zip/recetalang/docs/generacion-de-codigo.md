# Generación de código y máquina virtual

El generador convierte nodos del AST a tuplas `(operación, argumento)`. La máquina virtual mantiene una pila de evaluación, un diccionario de variables y el registro de la receta. Las etiquetas temporales de saltos se resuelven a índices antes de ejecutar.

## Traducciones

- Un entero genera `PUSH n`; una variable genera `LOAD nombre`.
- Una asignación genera su expresión y `STORE nombre`.
- Suma, resta y multiplicación generan los operandos en orden y luego `ADD`, `SUB` o `MUL`; el menos unario genera `NEG`.
- `agregar` apila ingrediente, cantidad y unidad antes de `AGREGAR`; la VM los desapila en orden inverso.
- `mezclar` y `cocinar` generan la expresión de minutos y una instrucción que la registra.
- Un condicional evalúa ambos operandos, compara y usa `JZ` para saltar a `sino`; al terminar la rama verdadera, `JMP` salta al final.
- `repetir` guarda el número de vueltas en `$repN`, comprueba que sea mayor que cero, ejecuta el cuerpo, resta uno y vuelve a la etiqueta inicial.

## Ejemplo por líneas del programa 03

1. `porciones = 4` produce `PUSH 4; STORE porciones`.
2. `si porciones > 2 entonces` produce `LOAD porciones; PUSH 2; GT; JZ L_sino`.
3. La rama elegida genera `PUSH arroz; PUSH 300; PUSH g; AGREGAR`; `JMP L_fin` evita la alternativa.
4. `repetir 2 veces` inicializa `$rep0`, compara con cero, registra `MEZCLAR(minutos=1)`, decrementa el contador y salta al inicio hasta completar dos vueltas.
5. `si porciones < 5 entonces` compara con `LT` y genera el `AGREGAR` de agua en la rama seleccionada.
6. `si porciones == 4 entonces` compara con `EQ` y registra `COCINAR(minutos=25)`; los saltos evitan ejecutar la otra alternativa.

Los nombres de etiquetas y contadores se asignan en orden de recorrido, de modo que la misma entrada siempre produce la misma lista de bytecode. La VM limita cada ejecución a 100 000 pasos para detectar un salto que no termina.
