# Commits sugeridos — Fase 5

## Juan Sebastian Palacios Encarnación

```text
feat(semantic): implementar tabla de símbolos y fusión de ramas
```

Incluye `recetalang/tabla_simbolos.py`.

## Yeiner Palacios Mena

```text
feat(semantic): validar variables y plegar expresiones conocidas
```

Incluye `recetalang/semantico.py` y su integración en `compilador.py`.

## Carlos Daniel Martínez Palacios

```text
test(semantic): cubrir variables, ramas y bucles
```

Incluye `pruebas/test_variables.py`, la opción `--simbolos` y la guía de fase.
