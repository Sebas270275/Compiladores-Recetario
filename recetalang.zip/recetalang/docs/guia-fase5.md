# Guía de la Fase 5 — Variables y tabla de símbolos

## Archivos nuevos o ampliados

- `recetalang/tabla_simbolos.py` conserva las variables definidas y sus valores enteros o desconocidos.
- `recetalang/semantico.py` evalúa expresiones y encuentra usos de variables no definidas.
- `recetalang/compilador.py` incluye el análisis semántico después de un parseo correcto.
- `recetalang/__main__.py` muestra la tabla con `--simbolos`.
- `pruebas/test_variables.py` prueba reasignaciones, ramas, bucles y posiciones de errores.

## Preguntas probables

1. **¿Qué significa guardar `None`?** Que la variable existe, pero su valor no se puede determinar estáticamente.
2. **¿Cómo evita `x = x + 1` crear una variable por accidente?** Evalúa primero el lado derecho y solo define `x` después.
3. **¿Por qué fusionar las ramas?** Al salir de un `si`, solo se puede afirmar que existe lo definido en ambas alternativas.
4. **¿Qué pasa con una variable modificada en un bucle?** Se marca desconocida al entrar al cuerpo para no asumir el valor de una vuelta concreta.
5. **¿En qué posición se reporta una variable ausente?** En la posición del identificador usado, como la columna 18 de `cantidad` en el programa 06.
