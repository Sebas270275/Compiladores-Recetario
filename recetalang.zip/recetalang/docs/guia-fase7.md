# Guía de la Fase 7 — Bytecode y máquina virtual

## Archivos nuevos o ampliados

- `recetalang/generador.py` traduce el AST a instrucciones de pila y resuelve saltos.
- `recetalang/maquina_virtual.py` ejecuta las instrucciones y produce las líneas del registro culinario.
- `recetalang/compilador.py` genera código solo después de pasar el análisis semántico.
- `recetalang/__main__.py` incorpora ejecución normal, `--bytecode` y `--solo-compilar`.
- `pruebas/test_generador_vm.py` compara salidas de referencia y prueba bucles, saltos y determinismo.
- `docs/generacion-de-codigo.md` explica las traducciones, incluido el programa 03.

## Preguntas probables

1. **¿Qué es una máquina de pila?** Cada operación toma sus operandos del tope y deja el resultado de vuelta en la pila.
2. **¿Cómo se traduce una condición?** Compara expresiones, y `JZ` salta a la rama falsa cuando el resultado es cero.
3. **¿Cómo se implementa `repetir`?** Guarda un contador oculto, lo compara con cero, ejecuta el cuerpo, lo decrementa y vuelve al inicio.
4. **¿Por qué el contador se llama `$rep0`?** Evita chocar con identificadores del usuario, que no permiten `$`.
5. **¿Qué evita un bucle infinito?** La VM cuenta pasos y falla claramente al superar 100 000.
