# Reparto rotativo del trabajo

En cada fase, cada integrante desarrolla un bloque pequeño y prepara su propio commit con su identidad Git. El primer bloque rota por fase para repartir la coordinación; los tres revisan el resultado antes de entregar. Los mensajes propuestos por fase detallan los commits sugeridos.

| Fase | Juan Sebastian Palacios Encarnación | Yeiner Palacios Mena | Carlos Daniel Martínez Palacios |
|---|---|---|---|
| 1 | Estructura del proyecto y documentación base | Nueve ejemplos y resultados esperados | Empaquetador, revisión de posiciones y entrega zip |
| 2 | Tokens y errores | Lexer y casos de tokenización | CLI de tokens y pruebas léxicas |
| 3 | Gramática EBNF y nodos AST | Parser de expresiones e instrucciones | Parser de bloques, errores y pruebas |
| 4 | Orquestador parcial y casos integrados | Ejecutor de pruebas y resultados | Informe de Actividad 5 y revisión cruzada |
| 5 | Tabla de símbolos y copias | Evaluación de expresiones y asignaciones | Flujo de ramas/bucles, CLI y pruebas |
| 6 | R1, R2 y R3 | R4 y seguimiento de ingredientes | U1, documentación y pruebas semánticas |
| 7 | Generación de expresiones y asignaciones | Generación de bloques y saltos | Máquina virtual, pruebas e integración |
| 8 | Informe de decisiones y README final | Guía de defensa y ejemplos extra | Pruebas finales, paquetes y matriz de cumplimiento |

La tabla indica contribuciones y no autoría de commits ya realizados. Cada persona registra sus cambios con su propia cuenta; los commits sugeridos están en `docs/commits-sugeridos-faseN.md`.
