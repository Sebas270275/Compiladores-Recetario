# Fases del compilador

- **Léxica:** convierte los caracteres del programa en tokens de RecetaLang e informa símbolos y cadenas mal formados.
- **Sintáctica:** comprueba que los tokens formen asignaciones, instrucciones culinarias y bloques válidos, y construye el AST.
- **Semántica:** valida variables y reglas del recetario, como cantidades positivas y agregar ingredientes antes de mezclar.
- **Generación de código:** traduce el AST validado a bytecode y una máquina virtual lo ejecuta para producir el registro de la receta.

```mermaid
flowchart LR
    A[Texto .receta] --> B[Análisis léxico]
    B --> C[Tokens]
    C --> D[Análisis sintáctico]
    D --> E[AST]
    E --> F[Análisis semántico]
    F --> G[AST validado]
    G --> H[Generación de bytecode]
    H --> I[Máquina virtual]
    I --> J[Registro de receta]
```
