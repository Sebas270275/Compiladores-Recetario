# Programas de entrega — Actividad 3

Esta carpeta contiene exactamente los seis programas solicitados: tres correctos y tres con errores intencionales.

## Programas buenos

### 01 — Preparación básica

Comando: `python -m recetalang ejemplos/actividad3/01_bueno_preparacion_basica.receta`

```text
AGREGAR(ingrediente=harina, cantidad=200, unidad=g)
AGREGAR(ingrediente=leche, cantidad=150, unidad=ml)
MEZCLAR(minutos=3)
COCINAR(minutos=25)
```

### 02 — Cantidades calculadas

Comando: `python -m recetalang ejemplos/actividad3/02_bueno_cantidades_calculadas.receta`

```text
AGREGAR(ingrediente=harina, cantidad=160, unidad=g)
AGREGAR(ingrediente=agua, cantidad=150, unidad=ml)
MEZCLAR(minutos=2)
COCINAR(minutos=20)
```

### 03 — Repeticiones y decisiones

Comando: `python -m recetalang ejemplos/actividad3/03_bueno_repeticiones_y_decisiones.receta`

```text
AGREGAR(ingrediente=arroz, cantidad=300, unidad=g)
MEZCLAR(minutos=1)
MEZCLAR(minutos=1)
AGREGAR(ingrediente=agua, cantidad=500, unidad=ml)
COCINAR(minutos=25)
```

## Programas malos

### 04 — Error léxico

El símbolo `@` no pertenece al lenguaje.

```text
Línea 1, columna 27: símbolo no reconocido «@»
```

### 05 — Error sintáctico

La repetición no tiene el `fin` que cierra su bloque.

```text
Línea 4, columna 1: se esperaba «fin» antes del final del archivo
```

### 06 — Error semántico

Se usa `cantidad` antes de definir la variable.

```text
Línea 2, columna 18: la variable «cantidad» no está definida
```

Los programas malos deben terminar con código de salida 1 y mostrar el error indicado.
