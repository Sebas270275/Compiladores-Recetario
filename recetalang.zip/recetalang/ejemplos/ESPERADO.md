# Resultados esperados de los ejemplos

Los registros siguientes corresponden a ejecutar los programas válidos. Los ejemplos inválidos deben detenerse en la fase indicada y producir exactamente el mensaje señalado; la CLI podrá anteponer el nombre de la fase.

## 01 — Preparación básica

Fase esperada: ejecución correcta.

```text
AGREGAR(ingrediente=harina, cantidad=200, unidad=g)
AGREGAR(ingrediente=leche, cantidad=150, unidad=ml)
MEZCLAR(minutos=3)
COCINAR(minutos=25)
```

## 02 — Cantidades calculadas

Fase esperada: ejecución correcta. `harina` vale 160, `agua` vale 150 y `tiempo` vale 20.

```text
AGREGAR(ingrediente=harina, cantidad=160, unidad=g)
AGREGAR(ingrediente=agua, cantidad=150, unidad=ml)
MEZCLAR(minutos=2)
COCINAR(minutos=20)
```

## 03 — Repeticiones y decisiones

Fase esperada: ejecución correcta. Con `porciones = 4`, se eligen 300 g de arroz, dos mezclas, 500 ml de agua y 25 minutos de cocción.

```text
AGREGAR(ingrediente=arroz, cantidad=300, unidad=g)
MEZCLAR(minutos=1)
MEZCLAR(minutos=1)
AGREGAR(ingrediente=agua, cantidad=500, unidad=ml)
COCINAR(minutos=25)
```

## 04 — Error léxico

Fase esperada: léxica.

```text
Línea 1, columna 27: símbolo no reconocido «@»
```

## 05 — Bloque sin cerrar

Fase esperada: sintáctica. El EOF está en la línea 4, columna 1 porque el archivo termina con salto de línea.

```text
Línea 4, columna 1: se esperaba «fin» antes del final del archivo
```

## 06 — Variable no definida

Fase esperada: semántica.

```text
Línea 2, columna 18: la variable «cantidad» no está definida
```

## 07 — Bloques anidados y reasignación

Fase esperada: ejecución correcta. En la primera vuelta `porciones` vale 2 y se agregan 80 g; después vale 1 y se agregan 40 g. Al final se mezcla durante 2 minutos.

```text
AGREGAR(ingrediente=avena, cantidad=80, unidad=g)
AGREGAR(ingrediente=avena, cantidad=40, unidad=g)
MEZCLAR(minutos=2)
```

## 08 — Condicional sin `sino`

Fase esperada: sintáctica.

```text
Línea 3, columna 1: se esperaba «sino»
```

## 09 — Repetición no positiva

Fase esperada: semántica.

```text
Línea 2, columna 9: [R3] la repetición debe ser mayor que cero (valor: -2)
```

## Casos adicionales para fases semánticas

- `extra/r1_cantidad_negativa.receta`: debe producir R1 por cantidad negativa.
- `extra/r2_tiempo_negativo.receta`: debe producir R2 por tiempo negativo.
- `extra/r4_cocinar_sin_ingredientes.receta`: debe producir R4.
- `extra/u1_unidad_invalida.receta`: debe producir U1 por la unidad `kg`.
- `extra/var_definida_en_una_sola_rama.receta`: debe reportar que `cantidad` no está definida después de la condición.
