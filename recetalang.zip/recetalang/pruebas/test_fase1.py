"""Comprueba los artefactos y las posiciones definidos en la Fase 1."""

from pathlib import Path
import unittest


RAIZ = Path(__file__).resolve().parent.parent


class PruebasCimientos(unittest.TestCase):
    """Asegura que ejemplos y documentación base sigan alineados."""

    def test_hay_nueve_programas_principales_y_cinco_extras(self) -> None:
        principales = sorted((RAIZ / "ejemplos").glob("??_*.receta"))
        extras = sorted((RAIZ / "ejemplos" / "extra").glob("*.receta"))
        self.assertEqual(len(principales), 9)
        self.assertEqual(len(extras), 5)

    def test_todos_los_programas_terminan_con_salto_de_linea(self) -> None:
        programas = list((RAIZ / "ejemplos").rglob("*.receta"))
        for programa in programas:
            with self.subTest(programa=programa.name):
                self.assertTrue(programa.read_bytes().endswith(b"\n"))

    def test_columnas_de_errores_de_referencia(self) -> None:
        linea_lexica = (RAIZ / "ejemplos" / "04_error_lexico.receta").read_text(
            encoding="utf-8"
        ).splitlines()[0]
        linea_semantica = (RAIZ / "ejemplos" / "06_error_semantico.receta").read_text(
            encoding="utf-8"
        ).splitlines()[1]
        linea_regla = (RAIZ / "ejemplos" / "09_error_regla_repetir.receta").read_text(
            encoding="utf-8"
        ).splitlines()[1]

        self.assertEqual(linea_lexica.index("@") + 1, 27)
        self.assertEqual(linea_semantica.index("cantidad") + 1, 18)
        self.assertEqual(linea_regla.index("-2") + 1, 9)

    def test_posicion_de_eof_y_mensajes_esperados(self) -> None:
        lineas = (RAIZ / "ejemplos" / "05_error_sintactico.receta").read_text(
            encoding="utf-8"
        ).splitlines()
        esperados = (RAIZ / "ejemplos" / "ESPERADO.md").read_text(encoding="utf-8")

        self.assertEqual(len(lineas) + 1, 4)
        self.assertIn("Línea 4, columna 1: se esperaba «fin» antes del final del archivo", esperados)
        self.assertIn("Línea 3, columna 1: se esperaba «sino»", esperados)


if __name__ == "__main__":
    unittest.main()
