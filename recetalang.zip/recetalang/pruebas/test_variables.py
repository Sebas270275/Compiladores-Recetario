"""Pruebas para la tabla de símbolos y su flujo entre bloques."""

import unittest

from recetalang.compilador import compilar
from recetalang.tabla_simbolos import TablaSimbolos


def analizar(texto: str):
    return compilar(texto, hasta_fase="semantico")


class PruebasVariables(unittest.TestCase):
    def test_tabla_define_copia_y_fusiona(self) -> None:
        original = TablaSimbolos({"x": 1})
        rama_a = original.copiar()
        rama_b = original.copiar()
        rama_a.definir("y", 2)
        rama_b.definir("y", 3)
        fusion = TablaSimbolos.fusionar_ramas(rama_a, rama_b)
        self.assertEqual(fusion.como_dict(), {"x": 1, "y": None})

    def test_variable_definida_y_reasignada(self) -> None:
        resultado = analizar("x = 3\nx = x * 4\ny = x + 2\n")
        self.assertEqual(resultado.errores, [])
        self.assertEqual(resultado.simbolos, {"x": 12, "y": 14})

    def test_uso_no_definido_del_programa_seis_posicion_exacta(self) -> None:
        from pathlib import Path

        raiz = Path(__file__).resolve().parent.parent
        ruta = raiz / "ejemplos" / "06_error_semantico.receta"
        resultado = analizar(ruta.read_text(encoding="utf-8"))
        error = resultado.errores[0]
        self.assertEqual((error.linea, error.columna), (2, 18))
        self.assertEqual(error.mensaje, "la variable «cantidad» no está definida")

    def test_uso_en_su_propia_asignacion_inicial(self) -> None:
        resultado = analizar("x = x + 1\n")
        self.assertEqual(len(resultado.errores), 1)
        self.assertEqual(resultado.errores[0].columna, 5)

    def test_definida_en_una_sola_rama_no_sobrevive(self) -> None:
        texto = (
            "si 1 > 0 entonces\n    x = 5\nsino\n    y = 2\n"
            "fin\nz = x + 1\n"
        )
        resultado = analizar(texto)
        self.assertEqual(len(resultado.errores), 1)
        self.assertIn("«x» no está definida", resultado.errores[0].mensaje)

    def test_definida_en_ambas_ramas_sobrevive(self) -> None:
        texto = (
            "si 1 > 0 entonces\n    x = 5\nsino\n    x = 5\n"
            "fin\ny = x + 1\n"
        )
        resultado = analizar(texto)
        self.assertEqual(resultado.errores, [])
        self.assertEqual(resultado.simbolos, {"x": 5, "y": 6})

    def test_valor_diferente_en_ramas_se_desconoce(self) -> None:
        texto = (
            "si 1 > 0 entonces\n    x = 5\nsino\n    x = 8\n"
            "fin\ny = x + 1\n"
        )
        resultado = analizar(texto)
        self.assertEqual(resultado.errores, [])
        self.assertIsNone(resultado.simbolos["x"])
        self.assertIsNone(resultado.simbolos["y"])

    def test_variable_definida_dentro_de_repetir_sobrevive(self) -> None:
        texto = "repetir 1 veces\n    cantidad = 8\nfin\nx = cantidad + 1\n"
        resultado = analizar(texto)
        self.assertEqual(resultado.errores, [])
        self.assertEqual(resultado.simbolos, {"cantidad": 8, "x": 9})

    def test_variable_modificada_en_repetir_pasa_a_desconocida(self) -> None:
        texto = "n = 1\nrepetir 2 veces\n    n = n + 1\nfin\nx = n + 2\n"
        resultado = analizar(texto)
        self.assertEqual(resultado.errores, [])
        self.assertIsNone(resultado.simbolos["n"])
        self.assertIsNone(resultado.simbolos["x"])

    def test_se_reportan_todos_los_usos_no_definidos(self) -> None:
        texto = 'agregar "a", falta1, "g"\nmezclar falta2\n'
        resultado = analizar(texto)
        self.assertEqual(len(resultado.errores), 2)
        self.assertEqual([error.linea for error in resultado.errores], [1, 2])


if __name__ == "__main__":
    unittest.main()
