"""Pruebas del reconocimiento de tokens y posiciones del lexer."""

from pathlib import Path
import unittest

from recetalang.lexer import tokenizar
from recetalang.tokens import TipoToken


RAIZ = Path(__file__).resolve().parent.parent


class PruebasLexer(unittest.TestCase):
    """Comprueba clases, límites de línea y recuperación léxica."""

    def test_reconoce_todas_las_clases_y_palabras_reservadas(self) -> None:
        texto = 'agregar mezclar cocinar repetir veces si entonces sino fin x 123 "arroz" = + - * > < == , ( )'
        tokens, errores = tokenizar(texto)
        tipos = {token.tipo for token in tokens}
        esperados = set(TipoToken) - {TipoToken.NEWLINE, TipoToken.EOF}
        self.assertEqual(errores, [])
        self.assertEqual(tipos & esperados, esperados)

    def test_distingue_asignacion_igualdad_y_mayusculas(self) -> None:
        tokens, errores = tokenizar("porciones = 2\nPorciones == 2\n")
        identificadores = [t.lexema for t in tokens if t.tipo == TipoToken.IDENTIFICADOR]
        operadores = [t.tipo for t in tokens if t.tipo in {TipoToken.IGUAL, TipoToken.IGUAL_IGUAL}]
        self.assertEqual(errores, [])
        self.assertEqual(identificadores, ["porciones", "Porciones"])
        self.assertEqual(operadores, [TipoToken.IGUAL, TipoToken.IGUAL_IGUAL])

    def test_admite_identificadores_con_letras_unicode(self) -> None:
        tokens, errores = tokenizar("porción_ñ2 = 7\n")
        self.assertEqual(errores, [])
        self.assertEqual(tokens[0].lexema, "porción_ñ2")

    def test_entero_usa_digitos_ascii_del_lenguaje(self) -> None:
        _, errores = tokenizar("١\n")
        self.assertEqual(len(errores), 1)
        self.assertEqual(errores[0].mensaje, "símbolo no reconocido «١»")

    def test_colapsa_lineas_vacias_y_ubica_eof_con_crlf(self) -> None:
        tokens, errores = tokenizar("\r\n\r\nx = 1\r\n\r\n")
        saltos = [t for t in tokens if t.tipo == TipoToken.NEWLINE]
        eof = tokens[-1]
        self.assertEqual(errores, [])
        self.assertEqual(len(saltos), 1)
        self.assertEqual((eof.linea, eof.columna), (5, 1))

    def test_archivo_vacio_solo_emite_eof(self) -> None:
        tokens, errores = tokenizar("")
        self.assertEqual(errores, [])
        self.assertEqual([t.tipo for t in tokens], [TipoToken.EOF])

    def test_reune_varios_simbolos_no_reconocidos(self) -> None:
        _, errores = tokenizar("x @ y @\n")
        self.assertEqual(len(errores), 2)
        self.assertEqual([e.columna for e in errores], [3, 7])
        self.assertEqual([e.mensaje for e in errores], [
            "símbolo no reconocido «@»",
            "símbolo no reconocido «@»",
        ])

    def test_cadena_sin_cierre_reporta_posicion_y_sigue_leyendo(self) -> None:
        tokens, errores = tokenizar('x = "sin cierre\ny = 2\n')
        self.assertEqual(len(errores), 1)
        self.assertEqual((errores[0].linea, errores[0].columna), (1, 5))
        self.assertTrue(any(t.lexema == "y" for t in tokens))

    def test_solo_el_ejemplo_cuatro_tiene_error_lexico(self) -> None:
        ejemplos = sorted((RAIZ / "ejemplos").glob("??_*.receta"))
        nombres_con_error = []
        for ruta in ejemplos:
            _, errores = tokenizar(ruta.read_text(encoding="utf-8"))
            if errores:
                nombres_con_error.append(ruta.name)
        self.assertEqual(nombres_con_error, ["04_error_lexico.receta"])


if __name__ == "__main__":
    unittest.main()
