"""Pruebas del parser recursivo, las expresiones y los bloques."""

from pathlib import Path
import unittest

from recetalang.ast_nodos import (
    Asignacion,
    Numero,
    OperacionBinaria,
    OperacionUnaria,
    Programa,
    Variable,
)
from recetalang.errores import ErrorCompilador
from recetalang.lexer import tokenizar
from recetalang.parser import parsear


RAIZ = Path(__file__).resolve().parent.parent


def analizar(texto: str) -> Programa:
    tokens, errores = tokenizar(texto)
    if errores:
        raise errores[0]
    return parsear(tokens)


def evaluar(expresion) -> int:
    """Evalúa solo los nodos aritméticos usados por estas pruebas."""
    if isinstance(expresion, Numero):
        return expresion.valor
    if isinstance(expresion, Variable):
        raise AssertionError("esta prueba no debe evaluar variables")
    if isinstance(expresion, OperacionUnaria):
        return -evaluar(expresion.operando)
    if isinstance(expresion, OperacionBinaria):
        izquierda = evaluar(expresion.izquierda)
        derecha = evaluar(expresion.derecha)
        if expresion.operador == "+":
            return izquierda + derecha
        if expresion.operador == "-":
            return izquierda - derecha
        return izquierda * derecha
    raise AssertionError(f"nodo no contemplado: {expresion!r}")


class PruebasParser(unittest.TestCase):
    """Valida que la gramática se convierta en estructuras claras."""

    def test_precedencia_multiplicacion_sobre_suma(self) -> None:
        ast = analizar("resultado = 2 + 3 * 4\n")
        asignacion = ast.sentencias[0]
        self.assertEqual(evaluar(asignacion.expresion), 14)

    def test_parentesis_y_menos_unario(self) -> None:
        ast = analizar("a = 2 * (3 + 4)\nb = -3\nc = 10 - -3\n")
        valores = [evaluar(sentencia.expresion) for sentencia in ast.sentencias]
        self.assertEqual(valores, [14, -3, 13])

    def test_anidamiento_de_tres_niveles(self) -> None:
        programa = """repetir 1 veces
    si 1 > 0 entonces
        repetir 1 veces
            mezclar 1
        fin
    sino
        cocinar 1
    fin
fin
"""
        ast = analizar(programa)
        self.assertEqual(len(ast.sentencias), 1)
        self.assertEqual(len(ast.sentencias[0].cuerpo[0].rama_si), 1)

    def test_fin_y_sino_sueltos_dan_error(self) -> None:
        for texto, esperado in [("fin\n", "«fin» sin bloque abierto"),
                                ("sino\n", "«sino» sin bloque abierto")]:
            with self.subTest(texto=texto), self.assertRaises(ErrorCompilador) as contexto:
                analizar(texto)
            self.assertEqual(contexto.exception.mensaje, esperado)

    def test_programa_cinco_y_ocho_tienen_mensaje_y_posicion_exactos(self) -> None:
        casos = [
            (
                "05_error_sintactico.receta",
                (4, 1),
                "se esperaba «fin» antes del final del archivo",
            ),
            (
                "08_error_sintactico_sin_sino.receta",
                (3, 1),
                "se esperaba «sino»",
            ),
        ]
        for nombre, posicion, mensaje in casos:
            texto = (RAIZ / "ejemplos" / nombre).read_text(encoding="utf-8")
            with self.subTest(nombre=nombre), self.assertRaises(ErrorCompilador) as contexto:
                analizar(texto)
            error = contexto.exception
            self.assertEqual((error.linea, error.columna), posicion)
            self.assertEqual(error.mensaje, mensaje)

    def test_ejemplos_01_02_03_y_07_se_parsean(self) -> None:
        nombres = [
            "01_preparacion_basica.receta",
            "02_cantidades_calculadas.receta",
            "03_repeticiones_y_decisiones.receta",
            "07_anidado_valido.receta",
        ]
        for nombre in nombres:
            with self.subTest(nombre=nombre):
                texto = (RAIZ / "ejemplos" / nombre).read_text(encoding="utf-8")
                self.assertIsInstance(analizar(texto), Programa)

    def test_ejemplos_semanticos_son_sintacticamente_validos(self) -> None:
        for nombre in ["06_error_semantico.receta", "09_error_regla_repetir.receta"]:
            texto = (RAIZ / "ejemplos" / nombre).read_text(encoding="utf-8")
            self.assertIsInstance(analizar(texto), Programa)

    def test_asignacion_es_un_nodo_con_identificador_y_expresion(self) -> None:
        sentencia = analizar("x = 9\n").sentencias[0]
        self.assertIsInstance(sentencia, Asignacion)
        self.assertEqual(sentencia.nombre, "x")


if __name__ == "__main__":
    unittest.main()
