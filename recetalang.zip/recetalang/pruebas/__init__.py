"""Pruebas automatizadas del proyecto RecetaLang."""
