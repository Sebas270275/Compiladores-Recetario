"""Pruebas del orden de ejecución entre lexer y parser."""

import unittest

from recetalang.compilador import compilar


class PruebasIntegracionLexicoSintactico(unittest.TestCase):
    def test_error_lexico_impide_analizar_la_sintaxis(self) -> None:
        resultado = compilar("@\nrepetir\n", hasta_fase="sintactico")
        self.assertEqual(resultado.fase, "Léxica")
        self.assertEqual(len(resultado.errores), 1)

    def test_error_sintactico_es_el_primer_error_y_no_pasa_a_semantica(self) -> None:
        resultado = compilar("x = (2 + )\n", hasta_fase=2)
        self.assertEqual(resultado.fase, "Sintáctica")
        self.assertEqual(len(resultado.errores), 1)
        self.assertIsNone(resultado.ast)

    def test_ejemplos_se_validan_hasta_sintaxis(self) -> None:
        from pathlib import Path

        raiz = Path(__file__).resolve().parent.parent
        for nombre in ["01_preparacion_basica.receta", "06_error_semantico.receta"]:
            texto = (raiz / "ejemplos" / nombre).read_text(encoding="utf-8")
            with self.subTest(nombre=nombre):
                resultado = compilar(texto, hasta_fase="sintactico")
                self.assertTrue(resultado.correcto)
                self.assertIsNotNone(resultado.ast)


if __name__ == "__main__":
    unittest.main()
