"""Verifica que el informe de cierre incluya todos los programas."""

import unittest
from pathlib import Path

from recetalang.compilador import compilar
from pruebas.ejecutar_pruebas import generar_resultados_final


RAIZ = Path(__file__).resolve().parent.parent


class PruebasIntegracionFinal(unittest.TestCase):
    def test_catorce_programas_coinciden_con_sus_resultados(self) -> None:
        informe = generar_resultados_final()
        self.assertIn("Resumen: 14 de 14 coinciden", informe)

    def test_carpeta_actividad3_tiene_tres_buenos_y_tres_malos(self) -> None:
        carpeta = RAIZ / "ejemplos" / "actividad3"
        programas = sorted(carpeta.glob("*.receta"))
        self.assertEqual(len(programas), 6)
        por_nombre = {programa.name: programa for programa in programas}
        buenos = sorted(nombre for nombre in por_nombre if "_bueno_" in nombre)
        malos = sorted(nombre for nombre in por_nombre if "_malo_" in nombre)
        self.assertEqual((len(buenos), len(malos)), (3, 3))
        for nombre in buenos:
            with self.subTest(nombre=nombre):
                resultado = compilar(
                    por_nombre[nombre].read_text(encoding="utf-8"),
                    hasta_fase="ejecucion",
                )
                self.assertEqual(resultado.errores, [])
                self.assertTrue(resultado.salida)
        fases = ["Léxica", "Sintáctica", "Semántica"]
        for nombre, fase in zip(malos, fases):
            with self.subTest(nombre=nombre):
                resultado = compilar(
                    por_nombre[nombre].read_text(encoding="utf-8"),
                    hasta_fase="ejecucion",
                )
                self.assertEqual(resultado.fase, fase)
                self.assertTrue(resultado.errores)


if __name__ == "__main__":
    unittest.main()
