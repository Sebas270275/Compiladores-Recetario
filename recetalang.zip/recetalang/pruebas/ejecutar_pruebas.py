"""Genera los informes de integración de las Actividades 5 y 7."""

from pathlib import Path
import re
import sys

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

from recetalang.compilador import compilar


def _secciones_esperadas() -> dict[str, str]:
    """Asocia el número de ejemplo con su sección de resultados esperados."""
    texto = (RAIZ / "ejemplos" / "ESPERADO.md").read_text(encoding="utf-8")
    partes = re.split(r"(?=^## \d{2} —)", texto, flags=re.MULTILINE)
    resultado = {}
    for parte in partes:
        coincidencia = re.match(r"## (\d{2}) —", parte)
        if coincidencia:
            resultado[coincidencia.group(1)] = parte
    return resultado


def _bloque_esperado(seccion: str) -> list[str]:
    bloques = re.findall(r"```text\s*\n(.*?)\n```", seccion, flags=re.DOTALL)
    return bloques[0].strip().splitlines() if bloques else []


def generar_resultados_actividad5() -> str:
    """Repite la aceptación de lexer/parser y guarda el informe de nueve casos."""
    secciones = _secciones_esperadas()
    lineas = ["Resultados integrados — Actividad 5", ""]
    coincidencias = 0
    ejemplos = sorted((RAIZ / "ejemplos").glob("??_*.receta"))
    for ruta in ejemplos:
        numero = ruta.name[:2]
        seccion = secciones[numero]
        resultado = compilar(ruta.read_text(encoding="utf-8"), hasta_fase="sintactico")
        fase_esperada = re.search(r"Fase esperada: ([^.]+)\.", seccion).group(1).strip()
        esperado = _bloque_esperado(seccion)
        if resultado.errores:
            mensajes = [error.formato() for error in resultado.errores]
            detalle = "\n".join(mensajes)
            coincide = len(mensajes) == 1 and mensajes == esperado
        elif fase_esperada == "semántica":
            detalle = "sintácticamente correcto; el error semántico se detecta en fases posteriores"
            coincide = bool(esperado)
        else:
            detalle = "OK: análisis léxico y sintáctico correcto"
            coincide = resultado.ast is not None
        coincidencias += int(coincide)
        lineas.extend(
            [
                ruta.name,
                f"  Fase de terminación: {resultado.fase}",
                f"  Resultado: {detalle}",
                f"  Coincide con ESPERADO.md: {'sí' if coincide else 'no'}",
                "",
            ]
        )
    lineas.append(f"Resumen: {coincidencias} de {len(ejemplos)} coinciden")
    contenido = "\n".join(lineas) + "\n"
    (RAIZ / "resultados" / "resultados_actividad5.txt").write_text(
        contenido, encoding="utf-8"
    )
    return contenido


_ESPERADOS_EXTRA = {
    "r1_cantidad_negativa.receta": (
        "Línea 1, columna 19: [R1] la cantidad debe ser mayor que cero (valor: -10)"
    ),
    "r2_tiempo_negativo.receta": (
        "Línea 2, columna 9: [R2] el tiempo debe ser mayor que cero (valor: -5)"
    ),
    "r4_cocinar_sin_ingredientes.receta": (
        "Línea 1, columna 1: [R4] se debe agregar al menos un ingrediente antes de mezclar o cocinar"
    ),
    "u1_unidad_invalida.receta": (
        "Línea 1, columna 23: [U1] unidad «kg» no admitida (use «g» o «ml»)"
    ),
    "var_definida_en_una_sola_rama.receta": (
        "Línea 6, columna 19: la variable «cantidad» no está definida"
    ),
}


def generar_resultados_final() -> str:
    """Compila nueve ejemplos y cinco extras por el flujo completo."""
    secciones = _secciones_esperadas()
    principales = sorted((RAIZ / "ejemplos").glob("??_*.receta"))
    extras = sorted((RAIZ / "ejemplos" / "extra").glob("*.receta"))
    lineas = ["Resultados de integración final — RecetaLang", ""]
    coincidencias = 0
    archivos = principales + extras

    for ruta in archivos:
        texto = ruta.read_text(encoding="utf-8")
        resultado = compilar(texto, hasta_fase="ejecucion")
        if ruta.parent.name == "extra":
            esperado = [_ESPERADOS_EXTRA[ruta.name]]
        else:
            esperado = _bloque_esperado(secciones[ruta.name[:2]])
        if resultado.errores:
            actual = [error.formato() for error in resultado.errores]
            detalle = "\n".join(actual)
        else:
            actual = resultado.salida
            detalle = "\n".join(actual) if actual else "Ejecución correcta sin registro de receta"
        coincide = actual == esperado
        coincidencias += int(coincide)
        lineas.extend(
            [
                ruta.relative_to(RAIZ / "ejemplos").as_posix(),
                f"  Fase de terminación: {resultado.fase}",
                f"  Errores o salida:\n{detalle}",
                f"  Coincide con lo esperado: {'sí' if coincide else 'no'}",
                "",
            ]
        )

    lineas.append(f"Resumen: {coincidencias} de {len(archivos)} coinciden")
    contenido = "\n".join(lineas) + "\n"
    (RAIZ / "resultados" / "resultados_final.txt").write_text(contenido, encoding="utf-8")
    return contenido


if __name__ == "__main__":
    generar_resultados_actividad5()
    print(generar_resultados_final(), end="")
