"""Pruebas de las reglas semánticas propias del dominio RecetaLang."""

from pathlib import Path
import unittest

from recetalang.compilador import compilar


RAIZ = Path(__file__).resolve().parent.parent


def errores(texto: str):
    return compilar(texto, hasta_fase="semantico").errores


class PruebasReglas(unittest.TestCase):
    def test_r1_cantidad_positiva_y_posicion(self) -> None:
        error = errores('agregar "harina",-10,"g"\n')[0]
        self.assertEqual((error.linea, error.columna), (1, 18))
        self.assertEqual(error.mensaje, "[R1] la cantidad debe ser mayor que cero (valor: -10)")
        self.assertEqual(errores('agregar "harina",10,"g"\n'), [])

    def test_r2_tiempo_positivo(self) -> None:
        resultado = errores('agregar "harina", 5, "g"\ncocinar -5\n')
        r2 = next(error for error in resultado if "[R2]" in error.mensaje)
        self.assertEqual((r2.linea, r2.columna), (2, 9))
        self.assertIn("valor: -5", r2.mensaje)
        self.assertEqual(errores('agregar "harina", 5, "g"\ncocinar 5\n'), [])

    def test_r3_repeticion_positiva_y_variable(self) -> None:
        texto = "n = 0\nrepetir n veces\n    x = 1\nfin\n"
        error = errores(texto)[0]
        self.assertEqual((error.linea, error.columna), (2, 9))
        self.assertIn("[R3] la repetición debe ser mayor que cero (valor: 0)", error.mensaje)
        self.assertEqual(errores("repetir 2 veces\n    x = 1\nfin\n"), [])

    def test_r4_exige_agregar_previo(self) -> None:
        error = errores("cocinar 10\n")[0]
        self.assertEqual((error.linea, error.columna), (1, 1))
        self.assertEqual(
            error.mensaje,
            "[R4] se debe agregar al menos un ingrediente antes de mezclar o cocinar",
        )
        valido = 'agregar "arroz", 5, "g"\ncocinar 10\n'
        self.assertEqual(errores(valido), [])

    def test_r4_solo_se_conserva_si_ambas_ramas_agregan(self) -> None:
        texto = (
            "si 1 > 0 entonces\n    agregar \"a\", 1, \"g\"\nsino\n"
            "    x = 1\nfin\ncocinar 2\n"
        )
        resultado = errores(texto)
        self.assertEqual(sum("[R4]" in error.mensaje for error in resultado), 1)
        valido = (
            "si 1 > 0 entonces\n    agregar \"a\", 1, \"g\"\nsino\n"
            "    agregar \"b\", 1, \"g\"\nfin\ncocinar 2\n"
        )
        self.assertEqual(errores(valido), [])

    def test_r4_agregado_en_repetir_cuenta_al_salir(self) -> None:
        texto = "repetir 1 veces\n    agregar \"a\", 1, \"g\"\nfin\ncocinar 2\n"
        self.assertEqual(errores(texto), [])

    def test_u1_unidad_admitida_en_fase_semantica(self) -> None:
        resultado = errores('agregar "harina", 5, "kg"\n')
        self.assertEqual(len(resultado), 1)
        self.assertEqual((resultado[0].linea, resultado[0].columna), (1, 23))
        self.assertEqual(
            resultado[0].mensaje,
            "[U1] unidad «kg» no admitida (use «g» o «ml»)",
        )
        self.assertEqual(errores('agregar "harina", 5, "ml"\n'), [])

    def test_programa_nueve_mensaje_r3_exacto(self) -> None:
        texto = (RAIZ / "ejemplos" / "09_error_regla_repetir.receta").read_text(encoding="utf-8")
        resultado = errores(texto)
        self.assertEqual(len(resultado), 1)
        self.assertEqual(
            resultado[0].formato(),
            "Línea 2, columna 9: [R3] la repetición debe ser mayor que cero (valor: -2)",
        )

    def test_no_reporta_regla_numerica_si_el_valor_es_desconocido(self) -> None:
        texto = "n = 1\nrepetir 1 veces\n    n = n + 1\nfin\nagregar \"a\", n, \"g\"\n"
        self.assertEqual(errores(texto), [])

    def test_programas_validos_siguen_sin_errores_semanticos(self) -> None:
        nombres = [
            "01_preparacion_basica.receta",
            "02_cantidades_calculadas.receta",
            "03_repeticiones_y_decisiones.receta",
            "07_anidado_valido.receta",
        ]
        for nombre in nombres:
            ruta = RAIZ / "ejemplos" / nombre
            with self.subTest(nombre=nombre):
                self.assertEqual(errores(ruta.read_text(encoding="utf-8")), [])

    def test_errores_semanticos_se_ordenan_por_linea(self) -> None:
        texto = 'agregar "a", 0, "kg"\ncocinar 0\n'
        resultado = errores(texto)
        self.assertEqual([error.linea for error in resultado], [1, 1, 2])


if __name__ == "__main__":
    unittest.main()
