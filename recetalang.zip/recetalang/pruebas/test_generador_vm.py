"""Pruebas del bytecode determinista y la ejecución de la máquina virtual."""

from pathlib import Path
import re
import unittest

from recetalang.compilador import compilar
from recetalang.generador import generar
from recetalang.lexer import tokenizar
from recetalang.maquina_virtual import ErrorMaquinaVirtual, ejecutar
from recetalang.parser import parsear


RAIZ = Path(__file__).resolve().parent.parent


def bloque_esperado(numero: str) -> list[str]:
    texto = (RAIZ / "ejemplos" / "ESPERADO.md").read_text(encoding="utf-8")
    partes = re.split(r"(?=^## \d{2} —)", texto, flags=re.MULTILINE)
    seccion = next(parte for parte in partes if parte.startswith(f"## {numero} —"))
    bloque = re.search(r"```text\s*\n(.*?)\n```", seccion, re.DOTALL).group(1)
    return bloque.splitlines()


def compilar_ejemplo(nombre: str):
    texto = (RAIZ / "ejemplos" / nombre).read_text(encoding="utf-8")
    return compilar(texto, hasta_fase="ejecucion")


class PruebasGeneradorYVM(unittest.TestCase):
    def test_salidas_de_01_02_03_y_07_coinciden_exactamente(self) -> None:
        casos = [
            ("01_preparacion_basica.receta", "01"),
            ("02_cantidades_calculadas.receta", "02"),
            ("03_repeticiones_y_decisiones.receta", "03"),
            ("07_anidado_valido.receta", "07"),
        ]
        for nombre, numero in casos:
            with self.subTest(nombre=nombre):
                resultado = compilar_ejemplo(nombre)
                self.assertEqual(resultado.errores, [])
                self.assertEqual(resultado.salida, bloque_esperado(numero))

    def test_repetir_anidado_ejecuta_las_seis_iteraciones(self) -> None:
        texto = (
            'agregar "a", 1, "g"\nrepetir 2 veces\n'
            "    repetir 3 veces\n        mezclar 1\n    fin\nfin\n"
        )
        resultado = compilar(texto, hasta_fase="ejecucion")
        self.assertEqual(resultado.errores, [])
        self.assertEqual(resultado.salida.count("MEZCLAR(minutos=1)"), 6)

    def test_condicional_anidado_dentro_de_repetir(self) -> None:
        texto = (
            'agregar "a", 1, "g"\nrepetir 2 veces\n'
            "    si 2 > 1 entonces\n        mezclar 1\n"
            "    sino\n        cocinar 1\n    fin\nfin\n"
        )
        resultado = compilar(texto, hasta_fase="ejecucion")
        self.assertEqual(resultado.errores, [])
        self.assertEqual(resultado.salida[1:], ["MEZCLAR(minutos=1)"] * 2)

    def test_precedencia_se_conserva_al_ejecutar(self) -> None:
        texto = 'agregar "a", 2 + 3 * 4, "g"\n'
        resultado = compilar(texto, hasta_fase="ejecucion")
        self.assertEqual(resultado.salida, ["AGREGAR(ingrediente=a, cantidad=14, unidad=g)"])

    def test_contador_oculto_no_choca_con_variable_de_usuario(self) -> None:
        texto = 'rep0 = 9\nagregar "a", rep0, "g"\nrepetir 2 veces\n    mezclar 1\nfin\n'
        resultado = compilar(texto, hasta_fase="ejecucion")
        self.assertEqual(resultado.errores, [])
        self.assertEqual(resultado.salida[0], "AGREGAR(ingrediente=a, cantidad=9, unidad=g)")
        self.assertEqual(resultado.salida[1:], ["MEZCLAR(minutos=1)"] * 2)

    def test_bytecode_es_determinista(self) -> None:
        texto = (RAIZ / "ejemplos" / "03_repeticiones_y_decisiones.receta").read_text(encoding="utf-8")
        tokens, errores = tokenizar(texto)
        self.assertEqual(errores, [])
        ast = parsear(tokens)
        self.assertEqual(generar(ast), generar(ast))

    def test_maquina_virtual_corta_un_bucle_infinito(self) -> None:
        with self.assertRaisesRegex(ErrorMaquinaVirtual, "límite de 10 pasos"):
            ejecutar([("JMP", 0)], max_pasos=10)

    def test_error_semantico_no_genera_bytecode(self) -> None:
        resultado = compilar('agregar "a", x, "g"\n', hasta_fase="ejecucion")
        self.assertTrue(resultado.errores)
        self.assertEqual(resultado.bytecode, [])


if __name__ == "__main__":
    unittest.main()
