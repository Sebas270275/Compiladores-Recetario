"""Empaqueta el estado del proyecto sin incluir entregas anteriores."""

from __future__ import annotations

import argparse
from pathlib import Path
import zipfile


def debe_excluir(ruta_relativa: Path) -> bool:
    """Omite archivos locales para que el paquete se pueda reconstruir."""
    if any(parte in {".git", "__pycache__", "entregas"} for parte in ruta_relativa.parts):
        return True
    return ruta_relativa.suffix == ".pyc"


def _escribir_zip(destino: Path) -> Path:
    """Escribe el árbol actual con una carpeta raíz uniforme."""
    raiz = Path(__file__).resolve().parent.parent
    with zipfile.ZipFile(destino, "w", compression=zipfile.ZIP_DEFLATED) as archivo_zip:
        for ruta in sorted(raiz.rglob("*")):
            if not ruta.is_file():
                continue
            relativa = ruta.relative_to(raiz)
            if debe_excluir(relativa):
                continue
            nombre_en_zip = Path("recetalang") / relativa
            archivo_zip.write(ruta, nombre_en_zip.as_posix())

    return destino


def empaquetar(numero: int, nombre_corto: str) -> Path:
    """Crea el zip de una fase y devuelve su ruta."""
    raiz = Path(__file__).resolve().parent.parent
    carpeta_entregas = raiz / "entregas"
    carpeta_entregas.mkdir(exist_ok=True)
    destino = carpeta_entregas / f"fase-{numero}-{nombre_corto}.zip"
    return _escribir_zip(destino)


def empaquetar_completo() -> Path:
    """Crea el paquete final con el nombre de entrega acordado."""
    raiz = Path(__file__).resolve().parent.parent
    carpeta_entregas = raiz / "entregas"
    carpeta_entregas.mkdir(exist_ok=True)
    destino = carpeta_entregas / "recetalang-compilador-completo.zip"
    return _escribir_zip(destino)


def main() -> int:
    """Lee los argumentos simples que identifican la fase y el paquete."""
    parser = argparse.ArgumentParser(description="Empaqueta el proyecto RecetaLang.")
    parser.add_argument("numero", type=int, help="número de fase")
    parser.add_argument("nombre_corto", help="nombre breve para el archivo zip")
    argumentos = parser.parse_args()

    if argumentos.numero < 1:
        parser.error("el número de fase debe ser positivo")
    if "/" in argumentos.nombre_corto or "\\" in argumentos.nombre_corto:
        parser.error("el nombre corto no puede contener separadores de ruta")

    destino = empaquetar(argumentos.numero, argumentos.nombre_corto)
    print(f"Paquete creado: {destino}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
