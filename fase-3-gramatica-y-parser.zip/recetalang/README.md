# RecetaLang

RecetaLang es un lenguaje pequeño de dominio específico para describir recetas. Este repositorio organiza el diseño y la implementación gradual de un compilador en ocho fases. En esta Fase 1 quedan preparados el diseño, los ejemplos y la estructura; las fases siguientes completarán los analizadores y la ejecución.

## Requisitos

- Python 3.10 o posterior.
- Solo biblioteca estándar de Python.

## Uso previsto

Cuando estén implementadas las fases correspondientes, se podrá ejecutar un programa con `python -m recetalang ejemplos/01_preparacion_basica.receta`. El proyecto también incluirá opciones para mostrar tokens, AST y bytecode. En esta fase esos módulos son espacios de trabajo documentados.

Para correr las pruebas que se incorporarán en fases posteriores: `python -m unittest discover -s pruebas`.

## Estructura

- `recetalang/`: módulos del compilador, organizados por responsabilidad.
- `gramatica/`: gramática formal del lenguaje (se completará en la Fase 3).
- `ejemplos/`: nueve programas de referencia y sus resultados esperados.
- `pruebas/`: pruebas automatizadas que se añadirán en fases posteriores.
- `docs/`: especificación, guías por fase y reparto del trabajo.
- `tools/empaquetar.py`: crea un zip reproducible del estado actual.
- `entregas/`: paquetes generados por fase; se excluye al empaquetar.

La especificación de referencia está en [docs/especificacion.md](docs/especificacion.md). Los resultados definidos a mano para los ejemplos están en [ejemplos/ESPERADO.md](ejemplos/ESPERADO.md).
