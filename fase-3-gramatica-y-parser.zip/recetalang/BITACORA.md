# Bitácora — RecetaLang

## Integrantes

- Juan Sebastian Palacios Encarnación
- Yeiner Palacios Mena
- Carlos Daniel Martínez Palacios

## Decisiones del grupo

Las decisiones D1–D13 provienen de la especificación base y se conservan para que lexer, parser y análisis semántico compartan el mismo comportamiento.

| Fecha | Decisión | Por qué | Quién la propuso |
|---|---|---|---|
| 2026-11-17 | D1. EOF se coloca justo después del último carácter; tras un salto final, en la línea siguiente, columna 1. | Hace reproducibles las posiciones de errores al final del archivo. | Especificación base |
| 2026-11-17 | D2. El lexer reúne todos los errores y bloquea el parser si encuentra alguno. | Permite informar varios problemas léxicos en una sola lectura. | Especificación base |
| 2026-11-17 | D3. El parser se detiene en el primer error y bloquea la semántica. | Mantiene sencillo el descenso recursivo sin recuperación sintáctica. | Especificación base |
| 2026-11-17 | D4. La semántica reúne todos los errores ordenados por línea y bloquea la generación de código. | Evita generar instrucciones para un programa inválido. | Especificación base |
| 2026-11-17 | D5. El lexer emite siempre el signo menos; el parser decide si es unario o binario. | La interpretación depende de su posición dentro de la expresión. | Especificación base |
| 2026-11-17 | D6. La tabla de símbolos conserva un entero conocido o `None`; se pliegan expresiones cuyos valores se conocen. | Permite validar valores constantes sin inventar valores para expresiones desconocidas. | Especificación base |
| 2026-11-17 | D7. Las dos ramas de un condicional se analizan en copias; después solo sobreviven las definiciones y hechos comunes. | El estado posterior no debe depender de una rama que quizá no ocurra. | Especificación base |
| 2026-11-17 | D8. El cuerpo de repetir corre al menos una vez; las variables asignadas allí pasan a desconocidas antes de analizarlo. | Es el modelo estático acordado para bucles con una o más iteraciones. | Especificación base |
| 2026-11-17 | D9. Los identificadores admiten letras Unicode, `_` inicial y dígitos posteriores; reservadas no son identificadores. | Incluye nombres con acentos y mantiene palabras estructurales inequívocas. | Especificación base |
| 2026-11-17 | D10. El nombre del ingrediente puede ser cualquier cadena, incluso con espacios o acentos. | El lenguaje no impone restricciones adicionales al nombre culinario. | Especificación base |
| 2026-11-17 | D11. Las unidades se validan semánticamente mediante U1. | Una cadena bien formada puede ser léxicamente válida aunque su unidad no se admita. | Especificación base |
| 2026-11-17 | D12. Los errores R1, R2 y R3 incluyen regla, valor y posición del inicio de la expresión. | Identifica tanto la causa como el fragmento que se debe revisar. | Especificación base |
| 2026-11-17 | D13. Esta versión no tiene comentarios. | Evita ampliar el lenguaje antes de la defensa; agregar comentarios queda como cambio posible. | Especificación base |

## Uso de Inteligencia Artificial

| Fecha | Integrante | Herramienta | Fase/actividad | Qué se pidió | Qué se aceptó / qué se cambió | Cómo se verificó |
|---|---|---|---|---|---|---|
| 2026-11-17 | `<INTEGRANTE: completar>` | Codex | Fase 1 — cimientos y diseño | Preparar estructura, documentación conceptual, ejemplos, resultados esperados y empaquetador. | Se generaron los artefactos iniciales; el grupo debe revisar el contenido y completar su nombre. | Verificado con `unittest` y revisión manual pendiente por el grupo. |
| 2026-11-18 | `<INTEGRANTE: completar>` | Codex | Fase 2 — analizador léxico | Implementar tokens, errores y lexer manual, junto con su opción CLI y pruebas. | Se aceptó el lexer con acumulación de errores, posiciones de base uno y lectura de CRLF. | Verificado con `unittest` y revisión manual pendiente por el grupo. |
| 2026-11-18 | `<INTEGRANTE: completar>` | Codex | Fase 3 — gramática y parser | Formalizar EBNF, definir AST, implementar descenso recursivo y documentar la gramática. | Se aceptó el parser con precedencia aritmética, bloques anidados y error sintáctico de primer fallo. | Verificado con `unittest` y revisión manual pendiente por el grupo. |

## Observaciones

- El DOCX de la Actividad 3 explica el diseño conceptual y los seis primeros programas; esta implementación sigue el prompt maestro como fuente de verdad cuando amplía o precisa esa propuesta, en particular para las reglas adicionales y los nueve ejemplos.
