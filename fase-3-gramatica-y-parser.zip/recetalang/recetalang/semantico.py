"""Análisis de variables y reglas semánticas (Fases 5 y 6)."""
