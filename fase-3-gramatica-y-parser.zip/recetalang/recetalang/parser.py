"""Parser de descenso recursivo: cada método corresponde a una regla."""

from recetalang.ast_nodos import (
    Agregar,
    Asignacion,
    Cocinar,
    Comparacion,
    Condicional,
    Expresion,
    Mezclar,
    Numero,
    OperacionBinaria,
    OperacionUnaria,
    Programa,
    Repetir,
    Sentencia,
    Variable,
)
from recetalang.errores import ErrorCompilador
from recetalang.tokens import TipoToken, Token


_NOMBRES = {
    TipoToken.FIN: "fin",
    TipoToken.SINO: "sino",
    TipoToken.IGUAL: "=",
    TipoToken.COMA: ",",
    TipoToken.PAREN_DER: ")",
    TipoToken.PAREN_IZQ: "(",
    TipoToken.VECES: "veces",
    TipoToken.ENTONCES: "entonces",
}


class Parser:
    """Consume tokens y se detiene en el primer error de sintaxis."""

    def __init__(self, tokens: list[Token]) -> None:
        self.tokens = tokens
        self.indice = 0

    def parsear(self) -> Programa:
        return self._programa()

    def _actual(self) -> Token:
        return self.tokens[self.indice]

    def _avanzar(self) -> Token:
        token = self._actual()
        if token.tipo != TipoToken.EOF:
            self.indice += 1
        return token

    def _esperar(self, tipo: TipoToken, descripcion: str | None = None) -> Token:
        token = self._actual()
        if token.tipo == tipo:
            return self._avanzar()
        esperado = descripcion or _NOMBRES.get(tipo, tipo.name.lower())
        if tipo == TipoToken.FIN and token.tipo == TipoToken.EOF:
            self._error(token, "se esperaba «fin» antes del final del archivo")
        if tipo == TipoToken.SINO:
            self._error(token, "se esperaba «sino»")
        self._error(token, f"se esperaba {esperado} pero se encontró «{token.lexema}»")

    def _error(self, token: Token, mensaje: str) -> None:
        raise ErrorCompilador(token.linea, token.columna, mensaje, "Sintáctica")

    def _fin_linea(self) -> None:
        if self._actual().tipo == TipoToken.NEWLINE:
            self._avanzar()
        elif self._actual().tipo != TipoToken.EOF:
            token = self._actual()
            self._error(
                token,
                f"se esperaba fin de línea pero se encontró «{token.lexema}»",
            )

    def _saltar_lineas(self) -> None:
        while self._actual().tipo == TipoToken.NEWLINE:
            self._avanzar()

    def _programa(self) -> Programa:
        sentencias: list[Sentencia] = []
        self._saltar_lineas()
        while self._actual().tipo != TipoToken.EOF:
            if self._actual().tipo in {TipoToken.FIN, TipoToken.SINO}:
                token = self._actual()
                self._error(token, f"«{token.lexema}» sin bloque abierto")
            sentencias.append(self._sentencia())
            self._saltar_lineas()
        return Programa(1, 1, sentencias)

    def _sentencia(self) -> Sentencia:
        tipo = self._actual().tipo
        if tipo == TipoToken.IDENTIFICADOR:
            return self._asignacion()
        if tipo == TipoToken.AGREGAR:
            return self._agregar()
        if tipo == TipoToken.MEZCLAR:
            return self._mezclar()
        if tipo == TipoToken.COCINAR:
            return self._cocinar()
        if tipo == TipoToken.REPETIR:
            return self._repetir()
        if tipo == TipoToken.SI:
            return self._condicional()
        token = self._actual()
        self._error(token, f"se esperaba una instrucción pero se encontró «{token.lexema}»")

    def _asignacion(self) -> Asignacion:
        nombre = self._esperar(TipoToken.IDENTIFICADOR)
        self._esperar(TipoToken.IGUAL, "«=»")
        expresion = self._expresion()
        self._fin_linea()
        return Asignacion(nombre.linea, nombre.columna, nombre.lexema, expresion)

    def _agregar(self) -> Agregar:
        inicio = self._esperar(TipoToken.AGREGAR)
        ingrediente = self._esperar(TipoToken.CADENA, "una cadena de ingrediente")
        self._esperar(TipoToken.COMA)
        cantidad = self._expresion()
        self._esperar(TipoToken.COMA)
        unidad = self._esperar(TipoToken.CADENA, "una cadena de unidad")
        self._fin_linea()
        return Agregar(
            inicio.linea,
            inicio.columna,
            str(ingrediente.valor),
            cantidad,
            str(unidad.valor),
            unidad.linea,
            unidad.columna + 1,
        )

    def _mezclar(self) -> Mezclar:
        inicio = self._esperar(TipoToken.MEZCLAR)
        tiempo = self._expresion()
        self._fin_linea()
        return Mezclar(inicio.linea, inicio.columna, tiempo)

    def _cocinar(self) -> Cocinar:
        inicio = self._esperar(TipoToken.COCINAR)
        tiempo = self._expresion()
        self._fin_linea()
        return Cocinar(inicio.linea, inicio.columna, tiempo)

    def _repetir(self) -> Repetir:
        inicio = self._esperar(TipoToken.REPETIR)
        veces = self._expresion()
        self._esperar(TipoToken.VECES)
        self._esperar(TipoToken.NEWLINE, "un fin de línea después de «veces»")
        cuerpo = self._bloque()
        self._esperar(TipoToken.FIN)
        self._fin_linea()
        return Repetir(inicio.linea, inicio.columna, veces, cuerpo)

    def _condicional(self) -> Condicional:
        inicio = self._esperar(TipoToken.SI)
        izquierda = self._expresion()
        op = self._actual()
        if op.tipo not in {TipoToken.MAYOR, TipoToken.MENOR, TipoToken.IGUAL_IGUAL}:
            self._error(op, "se esperaba un comparador «>», «<» o «==»")
        self._avanzar()
        derecha = self._expresion()
        condicion = Comparacion(
            izquierda.linea, izquierda.columna, izquierda, op.lexema, derecha
        )
        self._esperar(TipoToken.ENTONCES)
        self._esperar(TipoToken.NEWLINE, "un fin de línea después de «entonces»")
        rama_si = self._bloque(detener_en_sino=True)
        self._esperar(TipoToken.SINO)
        self._esperar(TipoToken.NEWLINE, "un fin de línea después de «sino»")
        rama_sino = self._bloque()
        self._esperar(TipoToken.FIN)
        self._fin_linea()
        return Condicional(inicio.linea, inicio.columna, condicion, rama_si, rama_sino)

    def _bloque(self, detener_en_sino: bool = False) -> list[Sentencia]:
        sentencias: list[Sentencia] = []
        self._saltar_lineas()
        while self._actual().tipo not in {TipoToken.EOF, TipoToken.FIN}:
            if self._actual().tipo == TipoToken.SINO:
                break
            sentencias.append(self._sentencia())
            self._saltar_lineas()
        return sentencias

    def _expresion(self) -> Expresion:
        izquierda = self._termino()
        while self._actual().tipo in {TipoToken.MAS, TipoToken.MENOS}:
            operador = self._avanzar()
            derecha = self._termino()
            izquierda = OperacionBinaria(
                operador.linea, operador.columna, operador.lexema, izquierda, derecha
            )
        return izquierda

    def _termino(self) -> Expresion:
        izquierda = self._factor()
        while self._actual().tipo == TipoToken.POR:
            operador = self._avanzar()
            derecha = self._factor()
            izquierda = OperacionBinaria(
                operador.linea, operador.columna, operador.lexema, izquierda, derecha
            )
        return izquierda

    def _factor(self) -> Expresion:
        token = self._actual()
        if token.tipo == TipoToken.ENTERO:
            self._avanzar()
            return Numero(token.linea, token.columna, int(token.valor))
        if token.tipo == TipoToken.IDENTIFICADOR:
            self._avanzar()
            return Variable(token.linea, token.columna, token.lexema)
        if token.tipo == TipoToken.MENOS:
            self._avanzar()
            operando = self._factor()
            return OperacionUnaria(token.linea, token.columna, "-", operando)
        if token.tipo == TipoToken.PAREN_IZQ:
            self._avanzar()
            expresion = self._expresion()
            self._esperar(TipoToken.PAREN_DER)
            return expresion
        self._error(token, f"se esperaba una expresión pero se encontró «{token.lexema}»")


def parsear(tokens: list[Token]) -> Programa:
    """Función pública para construir el AST a partir de los tokens."""
    return Parser(tokens).parsear()
