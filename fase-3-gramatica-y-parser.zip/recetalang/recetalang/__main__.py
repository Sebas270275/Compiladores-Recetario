"""Punto de entrada de la interfaz de línea de comandos."""

import argparse
from pathlib import Path
from pprint import pformat
import sys

from recetalang.errores import ErrorCompilador
from recetalang.lexer import tokenizar
from recetalang.parser import parsear


def main() -> int:
    """Permite inspeccionar tokens y AST desde un archivo de receta."""
    parser = argparse.ArgumentParser(prog="python -m recetalang")
    parser.add_argument("archivo", type=Path)
    parser.add_argument("--tokens", action="store_true", help="mostrar tokens")
    parser.add_argument("--ast", action="store_true", help="mostrar el AST")
    argumentos = parser.parse_args()
    try:
        texto = argumentos.archivo.read_text(encoding="utf-8")
    except OSError as error:
        print(f"No se pudo leer el archivo: {error}", file=sys.stderr)
        return 1

    tokens, errores = tokenizar(texto)
    if argumentos.tokens:
        print(f"{'LÍNEA':>5} {'COL':>4} {'TIPO':<16} LEXEMA")
        for token in tokens:
            lexema = token.lexema.replace("\n", "\\n")
            print(f"{token.linea:5} {token.columna:4} {token.tipo.name:<16} {lexema}")
    for error in errores:
        print(f"[{error.fase}] {error.formato()}", file=sys.stderr)
    if errores:
        return 1
    if argumentos.ast:
        try:
            print(pformat(parsear(tokens), width=88, sort_dicts=False))
        except ErrorCompilador as error:
            print(f"[{error.fase}] {error.formato()}", file=sys.stderr)
            return 1
    if not argumentos.tokens and not argumentos.ast:
        print("Análisis léxico correcto. Use --tokens o --ast para inspeccionar el programa.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
