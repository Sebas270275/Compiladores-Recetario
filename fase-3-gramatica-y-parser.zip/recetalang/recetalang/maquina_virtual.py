"""Máquina virtual del bytecode (se implementará en la Fase 7)."""
