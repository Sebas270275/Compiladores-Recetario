"""Tabla de símbolos para variables (se implementará en la Fase 5)."""
